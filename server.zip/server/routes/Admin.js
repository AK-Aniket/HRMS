import express, { json } from 'express'
import con from '../utils/db.js'
import jwt from 'jsonwebtoken'
/*import multer from 'multer'
import path from 'path'
import bodyParser from 'body-parser'*/

const router = express.Router()


/*adminpage---------------------------------------------------------------------------------------------------------------*/
router.post('/totalemployee', (req, res) => {
    // Query to count non-null values in the `name` column
    const sql = "SELECT COUNT(name) AS count FROM username";

    con.query(sql, (err, result) => {
        if (err) {
            console.error('Error in querying the database:', err);
            return res.status(500).json({ Status: false, Error: "Error in querying the database" });
        }

        if (result && result.length > 0) {
            const count = result[0].count;
            return res.json({ Status: true, Count: count });
        } else {
            return res.json({ Status: false, Error: "No records found" });
        }
    });

});


router.post('/activeemployee', (req, res) => {
    const sql = "SELECT COUNT(Name) as count FROM attendance WHERE date = ?";
    const sql1 = "SELECT COUNT(name) as count FROM axis_attendance WHERE date = ?";

    con.query(sql, [req.body.date], (err, result) => {
        if (err) {
            console.error('Error in querying the database:', err); // Debugging line
            return res.json({ Status: false, Error: "Error in querying the database" });
        }

        con.query(sql1, [req.body.date], (err, result) => {
            if (err) {
                console.error('Error in querying the database:', err); // Debugging line
                return res.json({ Status: false, Error: "Error in querying the database" });
            }

            if (result.length > 0) {
                const count = result[0].count;
                return res.json({ Status: true, Count: count });
            } else {
                return res.json({ Status: false, Error: "No records found for the given date" });
            }
        });
    });
});


router.post('/todaysapplication', (req, res) => {
    const sql = "SELECT COUNT(name) as count FROM applications WHERE date = ? AND email_to = 'Rega@regaenterprises.com' ";
    con.query(sql, [req.body.date], (err, result) => {
        if (err) {
            console.error('Error in querying the database:', err); // Debugging line
            return res.json({ Status: false, Error: "Error in querying the database" });
        }

        if (result.length > 0) {
            const count = result[0].count;
            return res.json({ Status: true, Count: count });
        } else {
            return res.json({ Status: false, Error: "No records found for the given date" });
        }
    });
});


router.post('/editemployee', (req, res) => {
    const sql = "UPDATE username SET name=?, password=?, department=? WHERE username=? AND password=?";
    con.query(sql, [req.body.newname, req.body.newpassword, req.body.newdepartment,
    req.body.username, req.body.pwd],
        (err, result) => {
            if (err) {
                console.error("Error executing query:", err);
                return res.json({ Status: false, Error: "Server Problem" });
            }
            console.log("Record added successfully:", result);
            return res.json({ Status: true });
        });
});


router.get('/attendancerecord', (req, res) => {
    const sql = "SELECT * FROM attendance ORDER BY date DESC, punch_In desc"; // Change 'date' to the relevant column name
    con.query(sql, (err, result) => {
        if (err) return res.json({ Status: false, Error: "Server Problem" });
        return res.json({ Status: true, Result: result });
    });
});


router.post('/edit', (req, res) => {
    const sql = "UPDATE payroll SET Date=?, Salary_slip_no=?, Employee_Name=?, Salary=?, Status=? WHERE Salary_slip_no=? AND Employee_Name=?";
    con.query(sql, [req.body.date, req.body.salaryDetail, req.body.namee, req.body.salary, req.body.staatus, req.body.slipno, req.body.old_employee_name], (err, result) => {
        if (err) {
            console.error("Error executing query:", err);
            return res.json({ Status: false, Error: "Server Problem" });
        }
        console.log("Record updated successfully:", result);
        return res.json({ Status: true });
    });
});


router.post('/axisedit', (req, res) => {
    const sql = "UPDATE axis_payroll SET name=?, ID=?, date=?, Amount_no=?, Micr=?, Account_no=?, Drawal_name=? WHERE name=? and date=?";
    con.query(sql, [req.body.newname, req.body.id, req.body.newdate, req.body.amountno, req.body.Micr, req.body.accountno,req.body.drawalname, req.body.name, req.body.date], (err, result) => {
        if (err) {
            console.error("Error executing query:", err);
            return res.json({ Status: false, Error: "Server Problem" });
        }
        console.log("Record added successfully:", result);
        return res.json({ Status: true });
    });
});


router.get('/adminaxispayroll', (req, res) => {
    const sql = "SELECT * FROM axis_payroll ORDER BY date DESC ";
    con.query(sql, (err, result) => {
        if (err) return res.json({ Status: false, Error: "Query error" })
        return res.json({ Status: true, Result: result })
    })
})


router.post('/deleteattendance', (req, res) => {
    const sql = "DELETE FROM attendance WHERE Name= ? AND date = ?";
    con.query(sql, [req.body.Name, req.body.date], (err, result) => {
        if (err) {
            console.error("Error executing query:", err);
            return res.json({ Status: false, Error: "Server Problem" });
        }
        console.log("Record added successfully:", result);
        return res.json({ Status: true });
    });
});


router.post('/adminpassword', (req, res) => {
    const sql = "UPDATE admin SET password=? WHERE username=? AND password=?";
    con.query(sql, [req.body.newpassword, req.body.username, req.body.oldpassword],
        (err, result) => {
            if (err) {
                console.error("Error changing password:", err);
                return res.json({ Status: false, Error: "Server error or query problem" });
            }
            if (result.affectedRows === 0) {
                return res.json({ Status: false, Error: "Incorrect old password" });
            }
            console.log("Password updated successfully:", result);
            return res.json({ Status: true });
        });
});


router.post('/add', (req, res) => {
    const sql = "INSERT INTO payroll (Date, Salary_slip_no, Employee_Name, Salary, Status) VALUES (?, ?, ?, ?, ?)";
    con.query(sql, [req.body.date, req.body.salaryDetail, req.body.namee, req.body.salary, req.body.staatus], (err, result) => {
        if (err) {
            console.error("Error executing query:", err);
            return res.json({ Status: false, Error: "Server Problem" });
        }
        console.log("Record added successfully:", result);
        return res.json({ Status: true });
    });
});


router.post('/addemployee', (req, res) => {
    const sql = "INSERT INTO username (id, name, username, password, department, status) VALUES (?, ?, ?, ?, ?, ?)";
    const sql2 = "INSERT INTO profile_images (name) VALUES (?)"
    con.query(sql, [req.body.Id, req.body.name, req.body.username, req.body.password, req.body.department, req.body.status], (err, result) => {
        if (err) {
            console.error("already exist:", err);
            return res.json({ Status: false, Error: "Server Problem" });
        }
        con.query(sql2, [req.body.username], (err, result) => {
            if (err) {
                console.error("already exist:", err);
                return res.json({ Status: false, Error: "Server Problem" });
            }
            console.log("Record added successfully:", result);
            return res.json({ Status: true });
        })
    });
});


router.post('/axisadd', (req, res) => {
    const sql = "INSERT INTO axis_payroll (name, ID, date, Amount_no, Micr, Account_no, Drawal_name) VALUES (?, ?, ?, ?, ?, ?, ?)";
    con.query(sql, [req.body.name, req.body.Id, req.body.date, req.body.amount, req.body.Micr, req.body.account,req.body.drawalname], (err, result) => {
        if (err) {
            console.error("Error executing query:", err);
            return res.json({ Status: false, Error: "Server Problem" });
        }
        console.log("Record added successfully:", result);
        return res.json({ Status: true });
    });
});

router.get('/adminpayroll', (req, res) => {
    const sql = "SELECT * FROM payroll ORDER BY date DESC ";
    con.query(sql, (err, result) => {
        if (err) return res.json({ Status: false, Error: "Query error" })
        return res.json({ Status: true, Result: result })
    })
})

router.post('/adminlogin', (req, res) => {
    const sql = "SELECT * FROM admin WHERE username = ? AND password = ?";
    con.query(sql, [req.body.username, req.body.password], (err, result) => {
        if (err) return res.json({ loginStatus: false, Error: "Wrong Username or Password" });
        if (result.length > 0) {
            const username = result[0].username;
            const token = jwt.sign({ role: 'admin', username: username }, 'jwt_secret_key', { expiresIn: '1d' });
            res.cookie('token', token);
            req.session.isAuthenticated = true;
            req.session.isAdmin = true;  // Set isAdmin to true for admin login
            return res.json({ loginStatus: true });
        } else {
            return res.json({ loginStatus: false, Error: "Wrong Username or Password" });
        }
    });
});

router.get('/check', (req, res) => {
    // Check if the user is authenticated and isAdmin
    res.json({ isAuthenticated: req.session.isAuthenticated, isAdmin: req.session.isAdmin });
});

router.get('/logout', (req, res) => {
    req.session.destroy();
    res.clearCookie('token');
    res.sendStatus(200);
});

router.post('/axisdelete', (req, res) => {
    const { slipnos } = req.body;

    if (!Array.isArray(slipnos) || slipnos.length === 0) {
        return res.json({ Status: false, Error: "No records specified for deletion." });
    }

    // Escape the values to prevent SQL injection
    const placeholders = slipnos.map(() => '?').join(',');
    const sql = `DELETE FROM axis_payroll WHERE ID IN (${placeholders})`;

    con.query(sql, slipnos, (err, result) => {
        if (err) {
            console.error("Error executing query:", err);
            return res.json({ Status: false, Error: "Server Problem" });
        }
        console.log("Records deleted successfully:", result);
        return res.json({ Status: true });
    });
});

router.post('/delete', (req, res) => {
    const { slipnos } = req.body;

    // Check if slipnos is an array and has elements
    if (!Array.isArray(slipnos) || slipnos.length === 0) {
        return res.json({ Status: false, Error: "No records specified for deletion." });
    }

    // Escape the values to prevent SQL injection
    const placeholders = slipnos.map(() => '?').join(',');
    const sql = `DELETE FROM payroll WHERE Salary_slip_no IN (${placeholders})`;

    con.query(sql, slipnos, (err, result) => {
        if (err) {
            console.error("Error executing query:", err);
            return res.json({ Status: false, Error: "Server Problem" });
        }
        console.log("Records deleted successfully:", result);
        return res.json({ Status: true });
    });
});

router.get('/axisattendancerecord', (req, res) => {
    const sql = "SELECT * FROM axis_attendance ORDER BY date DESC, punch_In desc"; // Change 'date' to the relevant column name
    con.query(sql, (err, result) => {
        if (err) return res.json({ Status: false, Error: "Server Problem" });
        return res.json({ Status: true, Result: result });
    });
});

router.get('/profile', (req, res) => {
    const sql = "SELECT * FROM username";
    con.query(sql, (err, result) => {
        if (err) return res.json({ Status: false, Error: "Server Problem" })
        return res.json({ Status: true, Result: result })
    })
})

router.post('/deleteprofile', (req, res) => {
    const sql = "DELETE FROM username WHERE username= ? ";
    const sql2= "DELETE FROM profile_images WHERE name= ?"
    con.query(sql, [req.body.username], (err, result) => {
        if (err) {
            console.error("Error executing query:", err);
            return res.json({ Status: false, Error: "Server Problem" });
        }
        con.query(sql2, [req.body.username], (err, result) => {
            if (err) {
                console.error("Error executing query:", err);
                return res.json({ Status: false, Error: "Server Problem" });
            }
        console.log("Record Deleted successfully:", result);
        return res.json({ Status: true });
        });
    });
});


/*userpage---------------------------------------------------------------------------------------------------------------*/


router.get('/payroll', (req, res) => {
    const sql = "SELECT * FROM payroll";
    con.query(sql, (err, result) => {
        if (err) return res.json({ Status: false, Error: "Server Problem" })
        return res.json({ Status: true, Result: result })
    })
})

router.post('/punchin', (req, res) => {
    const insertSql = "INSERT INTO attendance (Name, date, Punch_In, attendance) VALUES (?, ?, ?, ?)";
    const updateSql = "UPDATE username SET status = 'Active' WHERE name = ?";

    con.query(insertSql, [req.body.Name, req.body.date, req.body.Punch_In, req.body.stat], (err, result) => {
        if (err) {
            console.error("Error inserting punch in record", err);
            return res.status(500).json({ Status: false, Error: "Error inserting punch in record" });
        }

        con.query(updateSql, [req.body.Name], (err, updateResult) => {
            if (err) {
                console.error("Error updating user status", err);
                return res.status(500).json({ Status: false, Error: "Error updating user status" });
            }

            console.log("Successfully punched in and updated user status", result);
            return res.json({ Status: true });
        });
    });
});

router.post('/punchout', (req, res) => {
    const { date, Punch_Out, statu, attendanceStatus, Name } = req.body;
    const updateSql = "UPDATE username SET status = 'Inactive' WHERE name = ? ";
    // Assuming you have a `punchout` table to record punch-out data
    const sql = 'UPDATE attendance SET punch_out = ?, Working = ?, Status = ? WHERE date = ? AND name= ? ';
    con.query(sql, [Punch_Out, statu, attendanceStatus, date, Name], (err, result) => {
        if (err) {
            console.error("Error punching out:", err);
            return res.status(500).json({ Status: false, Error: "Error punching out" });
        }

        con.query(updateSql, [req.body.Name], (err, updateResult) => {
            if (err) {
                console.error("Error updating user status", err);
                return res.status(500).json({ Status: false, Error: "Error updating user status" });
            }
            console.log("Successfully punched out", result);
            return res.json({ Status: true });
        });
    });
});

router.post('/userlogin', (req, res) => {
    const sql = "SELECT * FROM username WHERE username = ? AND password = ?";
    con.query(sql, [req.body.username, req.body.password], (err, result) => {
        if (err) return res.json({ loginStatus: false, Error: "Server Problem" });
        if (result.length > 0) {
            const username = result[0].username;
            const token = jwt.sign({ role: 'username', username: username }, 'jwt_secret_key', { expiresIn: '1d' });
            res.cookie('token', token, { httpOnly: true }); // Set cookie with token
            req.session.isAuthenticated = true; // Set session variables as needed
            req.session.isAdmin = true;
            return res.json({ loginStatus: true, username: username }); // Send username along with loginStatus
        } else {
            return res.json({ loginStatus: false, Error: "Wrong username or password" });
        }
    });
});

// Handle start time (TB1)
router.post('/TB1', (req, res) => {
    const { Name, date, teabreakstart } = req.body;
    const updateSql = "UPDATE username SET status = 'Tea Break' WHERE name = ?";
    const sql = 'UPDATE attendance SET TB1 = ? WHERE date = ? AND name = ?';
    con.query(sql, [teabreakstart, date, Name], (err, result) => {
        if (err) {
            console.error("Error updating TB1:", err);
            return res.status(500).json({ Status: false, Error: "Error updating TB1" });
        }
        con.query(updateSql, [Name], (err, updateResult) => {
            if (err) {
                console.error("Error updating user status", err);
                return res.status(500).json({ Status: false, Error: "Error updating user status" });
            }
            console.log("Successfully recorded TB1", result);
            return res.json({ Status: true });
        });
    });
});

// Handle stop time and calculate tea break (TB2)
router.post('/TB2', (req, res) => {
    const { Name, date, teaBreakStop, statu } = req.body;
    const updateSql = "UPDATE username SET status = 'Active' WHERE name = ?";
    const sql = 'UPDATE attendance SET TB2 = ?, tea_break = ? WHERE date = ? AND name = ?';
    con.query(sql, [teaBreakStop, statu, date, Name], (err, result) => {
        if (err) {
            console.error("Error updating TB2:", err);
            return res.status(500).json({ Status: false, Error: "Error updating TB2" });
        }
        con.query(updateSql, [Name], (err, updateResult) => {
            if (err) {
                console.error("Error updating user status", err);
                return res.status(500).json({ Status: false, Error: "Error updating user status" });
            }
            console.log("Successfully recorded TB2 and tea break", result);
            return res.json({ Status: true });
        });
    });
});

router.post('/TB3', (req, res) => {
    const { Name, date, teabreakstart2 } = req.body;
    const updateSql = "UPDATE username SET status = 'Tea Break' WHERE name = ?";
    const sql = 'UPDATE attendance SET TB3 = ? WHERE date = ? AND name = ?';
    con.query(sql, [teabreakstart2, date, Name], (err, result) => {
        if (err) {
            console.error("Error updating TB1:", err);
            return res.status(500).json({ Status: false, Error: "Error updating TB1" });
        }
        con.query(updateSql, [Name], (err, updateResult) => {
            if (err) {
                console.error("Error updating user status", err);
                return res.status(500).json({ Status: false, Error: "Error updating user status" });
            }
            console.log("Successfully recorded TB1", result);
            return res.json({ Status: true });
        });
    });
});

router.post('/TB4', (req, res) => {
    const { Name, date, teaBreakstop2, statu } = req.body;
    const updateSql = "UPDATE username SET status = 'Active' WHERE name = ?";
    const sql = 'UPDATE attendance SET TB4 = ?, tea_break2 = ? WHERE date = ? AND name = ?';
    con.query(sql, [teaBreakstop2, statu, date, Name], (err, result) => {
        if (err) {
            console.error("Error updating TB2:", err);
            return res.status(500).json({ Status: false, Error: "Error updating TB2" });
        }
        con.query(updateSql, [Name], (err, updateResult) => {
            if (err) {
                console.error("Error updating user status", err);
                return res.status(500).json({ Status: false, Error: "Error updating user status" });
            }
            console.log("Successfully recorded TB2 and tea break", result);
            return res.json({ Status: true });
        });
    });
});

router.post('/LB1', (req, res) => {
    const { Name, date, lunchbreakstart } = req.body;
    const updateSql = "UPDATE username SET status = 'Lunch Break' WHERE name = ?";
    const sql = 'UPDATE attendance SET LB1 = ? WHERE date = ? AND name = ?';
    con.query(sql, [lunchbreakstart, date, Name], (err, result) => {
        if (err) {
            console.error("Error updating TB1:", err);
            return res.status(500).json({ Status: false, Error: "Error updating TB1" });
        }
        con.query(updateSql, [Name], (err, updateResult) => {
            if (err) {
                console.error("Error updating user status", err);
                return res.status(500).json({ Status: false, Error: "Error updating user status" });
            }
            console.log("Successfully recorded TB1", result);
            return res.json({ Status: true });
        });
    });
});

router.post('/LB2', (req, res) => {
    const { Name, date, lunchbreakstop, statu } = req.body;
    const updateSql = "UPDATE username SET status = 'Active' WHERE name = ?";
    const sql = 'UPDATE attendance SET LB2 = ?, lunch_break = ? WHERE date = ? AND name = ?';
    con.query(sql, [lunchbreakstop, statu, date, Name], (err, result) => {
        if (err) {
            console.error("Error updating TB2:", err);
            return res.status(500).json({ Status: false, Error: "Error updating TB2" });
        }
        con.query(updateSql, [Name], (err, updateResult) => {
            if (err) {
                console.error("Error updating user status", err);
                return res.status(500).json({ Status: false, Error: "Error updating user status" });
            }
            console.log("Successfully recorded TB2 and tea break", result);
            return res.json({ Status: true });
        });
    });
});

router.post('/emergencystart', (req, res) => {
    const { Name, date, emerbreakstart } = req.body;
    const updateSql = "UPDATE username SET status = 'Emergency Break' WHERE name = ?";
    const sql = 'UPDATE attendance SET start = ? WHERE date = ? AND name = ?';
    con.query(sql, [emerbreakstart, date, Name], (err, result) => {
        if (err) {
            console.error("Error updating TB1:", err);
            return res.status(500).json({ Status: false, Error: "Error updating TB1" });
        }
        con.query(updateSql, [Name], (err, updateResult) => {
            if (err) {
                console.error("Error updating user status", err);
                return res.status(500).json({ Status: false, Error: "Error updating user status" });
            }
            console.log("Successfully recorded TB1", result);
            return res.json({ Status: true });
        });
    });
});

router.post('/emergencystop', (req, res) => {
    const { Name, date, emerBreakstop, statu } = req.body;
    const updateSql = "UPDATE username SET status = 'Active' WHERE name = ?";
    const sql = 'UPDATE attendance SET end = ?, emergency = ? WHERE date = ? AND name = ?';
    con.query(sql, [emerBreakstop, statu, date, Name], (err, result) => {
        if (err) {
            console.error("Error updating ", err);
            return res.status(500).json({ Status: false, Error: "Error updating " });
        }
        con.query(updateSql, [Name], (err, updateResult) => {
            if (err) {
                console.error("Error updating user status", err);
                return res.status(500).json({ Status: false, Error: "Error updating user status" });
            }
            console.log("Successfully recorded TB2 and tea break", result);
            return res.json({ Status: true });
        });
    });
});

router.post('/changepassword', (req, res) => {
    const sql = "UPDATE username SET password=? WHERE username=? AND password=?";
    con.query(sql, [req.body.newpassword, req.body.username, req.body.oldpassword],
        (err, result) => {
            if (err) {
                console.error("Error changing password:", err);
                return res.json({ Status: false, Error: "Server error or query problem" });
            }
            if (result.affectedRows === 0) {
                return res.json({ Status: false, Error: "Incorrect old password" });
            }
            console.log("Password updated successfully:", result);
            return res.json({ Status: true });
        });
});


/*Anketpages---------------------------------------------------------------------------------------------------------------*/


router.get('/getAttendance', (req, res) => {
    const name = req.query.name; // Extract name from query parameters
    if (!name) {
        return res.status(400).json({ Status: false, Error: "Name parameter is required" });
    }

    const sql = "SELECT * FROM attendance WHERE Name = ?";
    con.query(sql, [name], (err, result) => {
        if (err) return res.status(500).json({ Status: false, Error: "Server Problem" });
        return res.json({ Status: true, Result: result });
    });
});

router.post('/getPunchTimes', (req, res) => {
    const sql = "SELECT * FROM attendance WHERE Name = ? AND date = ?";
    con.query(sql, [req.body.name, req.body.date], (err, result) => {
        if (err) {
            console.error("Error executing query:", err);
            return res.json({ Status: false, Error: "Server Problem" });
        }
        if (result.length > 0) {
            console.log("Record fetched successfully:", result);
            return res.json({ Status: true, Result: result[0] });
        } else {
            console.log("No record found for the given date and name.");
            return res.json({ Status: false, Error: "No record found" });
        }
    });
});


/* axis------------------------------------------------------------------------------------------------------------------------------------------- */


/*demo  */
router.post('/axispunchin', (req, res) => {
    const insertSql = "INSERT INTO axis_attendance (name, date, punch_in) VALUES (?, ?, ?)";
    const updateSql = "UPDATE username SET status = 'Active' WHERE name = ?";

    con.query(insertSql, [req.body.Name, req.body.date, req.body.Punch_In], (err, result) => {
        if (err) {
            console.error("Error inserting punch in record", err);
            return res.status(500).json({ Status: false, Error: "Error inserting punch in record" });
        }

        con.query(updateSql, [req.body.Name], (err, updateResult) => {
            if (err) {
                console.error("Error updating user status", err);
                return res.status(500).json({ Status: false, Error: "Error updating user status" });
            }

            console.log("Successfully punched in and updated user status", result);
            return res.json({ Status: true });
        });
    });
});

router.post('/axispunchout', (req, res) => {
    const { date, Punch_Out, statu, Name } = req.body;
    const updateSql = "UPDATE username SET status = 'Inactive' WHERE name = ? ";
    // Assuming you have a `punchout` table to record punch-out data
    const sql = 'UPDATE axis_attendance SET punch_out = ?, working_hrs = ? WHERE date = ? AND name= ? ';
    con.query(sql, [Punch_Out, statu, date, Name], (err, result) => {
        if (err) {
            console.error("Error punching out:", err);
            return res.status(500).json({ Status: false, Error: "Error punching out" });
        }

        con.query(updateSql, [req.body.Name], (err, updateResult) => {
            if (err) {
                console.error("Error updating user status", err);
                return res.status(500).json({ Status: false, Error: "Error updating user status" });
            }
            console.log("Successfully punched out", result);
            return res.json({ Status: true });
        });
    });
});

router.post('/axisdeleteattendance', (req, res) => {
    const sql = "DELETE FROM axis_attendance WHERE Name= ? AND date = ?";
    con.query(sql, [req.body.Name, req.body.date], (err, result) => {
        if (err) {
            console.error("Error executing query:", err);
            return res.json({ Status: false, Error: "Server Problem" });
        }
        console.log("Record added successfully:", result);
        return res.json({ Status: true });
    });
});

router.get('/axisgetAttendance', (req, res) => {
    const name = req.query.name; // Extract name from query parameters
    if (!name) {
        return res.status(400).json({ Status: false, Error: "Name parameter is required" });
    }

    const sql = "SELECT * FROM axis_attendance WHERE Name = ?";
    con.query(sql, [name], (err, result) => {
        if (err) return res.status(500).json({ Status: false, Error: "Server Problem" });
        return res.json({ Status: true, Result: result });
    });
});

router.post('/axisgetPunchTimes', (req, res) => {
    const sql = "SELECT * FROM axis_attendance WHERE Name = ? AND date = ?";
    con.query(sql, [req.body.name, req.body.date], (err, result) => {
        if (err) {
            console.error("Error executing query:", err);
            return res.json({ Status: false, Error: "Server Problem" });
        }
        if (result.length > 0) {
            console.log("Record fetched successfully:", result);
            return res.json({ Status: true, Result: result[0] });
        } else {
            console.log("No record found for the given date and name.");
            return res.json({ Status: false, Error: "No record found" });
        }
    });
});

router.get('/axispayroll', (req, res) => {
    const sql = "SELECT * FROM axis_payroll";
    con.query(sql, (err, result) => {
        if (err) return res.json({ Status: false, Error: "Server Problem" })
        return res.json({ Status: true, Result: result })
    })
})


export { router as adminRouter }