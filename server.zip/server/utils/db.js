import mysql from 'mysql2'

const con=mysql.createConnection({
    host:'localhost',
    user:'root',
    password:'AniketSharma',
    database: "rega",
    port:'3307'
    
})

con.connect(function(err) {
    if(err){
        console.log("connect error");
    }
    else{
        console.log("connect");
    }
})

export default con;