import express from 'express';
import cors from 'cors';
import session from 'express-session';
import bodyParser from 'body-parser';
import multer from 'multer';
import mysql from 'mysql2';
import { adminRouter } from './routes/Admin.js';

const app = express();

// MySQL connection pool
const pool = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'AniketSharma',
    database: 'rega',
    port:'3307'
});

pool.connect(function(err) {
    if(err){
        console.log("Second connect error");
    }
    else{
        console.log("Second connect");
    }
})

// Middleware
app.use(cors({
    origin: ["http://192.168.1.150:3001"],  // Ensure this is the correct frontend URL
    methods: ['GET', 'POST', 'PUT'],
    credentials: true
}));

// Start server
app.listen(3000, () => {
    console.log("Server running on port 3000");
});

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: false }  // Set this to true in production with HTTPS
}));

// File Storage Setup
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

// Routes
app.use('/auth', adminRouter);

app.post('/auth/send', upload.array('files'), (req, res) => {
    const { name, from, to, subject, message, date, time } = req.body;
    const files = req.files;

    let sql = "INSERT INTO applications (name, email_from, email_to, subject, message, date, time";
    let values = [name, from, to, subject, message, date, time];

    if (files && files.length > 0) {
        const file = files[0]; // Taking the first file for simplicity
        const fileName = file.originalname;
        const fileData = file.buffer;

        sql += ", file_name, file_data) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        values.push(fileName, fileData);
    } else {
        sql += ") VALUES (?, ?, ?, ?, ?, ?, ?)";
    }

    pool.query(sql, values, (err, result) => {
        if (err) {
            console.error("Error saving the application", err);
            return res.status(500).json({ Status: false, Error: "Error saving the application" });
        }
        console.log("Successfully saved the application", result);
        return res.json({ Status: true });
    });
});

app.get('/api/emails', (req, res) => {
    const sql = 'SELECT * FROM applications ORDER BY date DESC, time DESC'; // Fixed ordering
    pool.query(sql, (err, result) => {
        if (err) {
            console.error('Error fetching emails', err);
            res.status(500).json({ error: 'Failed to fetch emails' });
            return;
        }
        res.json(result);
    });
});


app.get('/auth/files/:filename', (req, res) => {
    const fileName = req.params.filename;
    const sql = "SELECT file_data FROM applications WHERE file_name = ? ";
    pool.query(sql, [fileName], (err, result) => {
        if (err) {
            console.error('Error fetching file:', err);
            res.status(500).send('Error fetching file');
            return;
        }
        if (result.length === 0) {
            res.status(404).send('File not found');
            return;
        }
        const fileData = result[0].file_data;
        res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
        res.setHeader('Content-Type', 'application/octet-stream');
        res.send(fileData);
    });
});



app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Helper function to convert image buffer to data URL
const bufferToDataUrl = (buffer, mimeType) => {
    return `data:${mimeType};base64,${buffer.toString('base64')}`;
};

// Fetch Profile Image
app.get('/auth/profileimage', (req, res) => {
    const { name } = req.query;

    const query = 'SELECT image FROM profile_images WHERE name = ?';
    pool.query(query, [name], (err, result) => {
        if (err) {
            return res.status(500).json({ Status: false, message: 'Error fetching profile image' });
        }
        if (result.length === 0 || !result[0].image) {
            return res.status(404).json({ Status: false, message: 'Profile image not found' });
        }
        const imageDataUrl = bufferToDataUrl(result[0].image, 'image/jpeg');
        res.json({ Status: true, imageDataUrl });
    });
});

// Fetch Aadhar Card Image
app.get('/auth/aadharcardimage', (req, res) => {
    const { name } = req.query;

    const query = 'SELECT aadharcard FROM profile_images WHERE name = ?';
    pool.query(query, [name], (err, result) => {
        if (err) {
            return res.status(500).json({ Status: false, message: 'Error fetching Aadhar card image' });
        }
        if (result.length === 0 || !result[0].aadharcard) {
            return res.status(404).json({ Status: false, message: 'Aadhar card image not found' });
        }
        const aadharcardDataUrl = bufferToDataUrl(result[0].aadharcard, 'image/jpeg');
        res.json({ Status: true, aadharcardDataUrl });
    });
});

// Fetch Pan Card Image
app.get('/auth/pancardimage', (req, res) => {
    const { name } = req.query;

    const query = 'SELECT pancard FROM profile_images WHERE name = ?';
    pool.query(query, [name], (err, result) => {
        if (err) {
            return res.status(500).json({ Status: false, message: 'Error fetching Pan card image' });
        }
        if (result.length === 0 || !result[0].pancard) {
            return res.status(404).json({ Status: false, message: 'Pan card image not found' });
        }
        const pancardDataUrl = bufferToDataUrl(result[0].pancard, 'image/jpeg');
        res.json({ Status: true, pancardDataUrl });
    });
});

// Fetch Qualification Image
app.get('/auth/qualificationimage', (req, res) => {
    const { name } = req.query;

    const query = 'SELECT qualification FROM profile_images WHERE name = ?';
    pool.query(query, [name], (err, result) => {
        if (err) {
            return res.status(500).json({ Status: false, message: 'Error fetching qualification image' });
        }
        if (result.length === 0 || !result[0].qualification) {
            return res.status(404).json({ Status: false, message: 'Qualification image not found' });
        }
        const qualificationDataUrl = bufferToDataUrl(result[0].qualification, 'image/jpeg');
        res.json({ Status: true, qualificationDataUrl });
    });
});

// Upload Profile Image
app.post('/auth/profileimage', upload.single('image'), (req, res) => {
    const image = req.file ? req.file.buffer : null;
    const name = req.body.name;

    if (!image || !name) {
        return res.status(400).json({ Status: false, message: 'Image and name are required' });
    }

    const query = 'UPDATE profile_images SET image=? WHERE name=?';
    pool.query(query, [image, name], (err, result) => {
        if (err) {
            return res.status(500).json({ Status: false, message: 'Error uploading profile image' });
        }
        res.json({ Status: true, message: 'Profile image uploaded successfully' });
    });
});

// Upload Aadhar Card Image
app.post('/auth/aadharcardimage', upload.single('aadharcard'), (req, res) => {
    const aadharcard = req.file ? req.file.buffer : null;
    const name = req.body.name;

    if (!aadharcard || !name) {
        return res.status(400).json({ Status: false, message: 'Aadhar card and name are required' });
    }

    const query = 'UPDATE profile_images SET aadharcard=? WHERE name=?';
    pool.query(query, [aadharcard, name ], (err, result) => {
        if (err) {
            return res.status(500).json({ Status: false, message: 'Error uploading Aadhar card image' });
        }
        res.json({ Status: true, message: 'Aadhar card image uploaded successfully' });
    });
});

// Upload Pan Card Image
app.post('/auth/pancardimage', upload.single('pancard'), (req, res) => {
    const pancard = req.file ? req.file.buffer : null;
    const name = req.body.name;

    if (!pancard || !name) {
        return res.status(400).json({ Status: false, message: 'Pan card and name are required' });
    }

    const query = 'UPDATE profile_images SET pancard=? WHERE name=?';
    pool.query(query, [pancard, name], (err, result) => {
        if (err) {
            return res.status(500).json({ Status: false, message: 'Error uploading Pan card image' });
        }
        res.json({ Status: true, message: 'Pan card image uploaded successfully' });
    });
});

// Upload Qualification Image
app.post('/auth/qualificationimage', upload.single('qualification'), (req, res) => {
    const qualification = req.file ? req.file.buffer : null;
    const name = req.body.name;

    if (!qualification || !name) {
        return res.status(400).json({ Status: false, message: 'Qualification image and name are required' });
    }

    const query = 'UPDATE profile_images SET qualification=? WHERE name=?';
    pool.query(query, [qualification, name], (err, result) => {
        if (err) {
            return res.status(500).json({ Status: false, message: 'Error uploading qualification image' });
        }
        res.json({ Status: true, message: 'Qualification image uploaded successfully' });
    });
});