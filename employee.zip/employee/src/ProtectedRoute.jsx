import { Navigate } from 'react-router-dom';
import { useAuth } from './AuthContext';

export const UserProtectedRoute = ({ children }) => {
    const { isAuthenticated } = useAuth();

    if (!isAuthenticated) {
        return <Navigate to="/" />;
    }

    return children;
};

export const AdminProtectedRoute = ({ children }) => {
    const { isAuthenticated, isAdmin } = useAuth();

    if (!isAuthenticated || !isAdmin) {
        return <Navigate to="/" />;
    }

    return children;
};
