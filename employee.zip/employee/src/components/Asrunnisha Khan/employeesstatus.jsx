import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import img1 from './image/logo.png';
import axios from 'axios';

const employeesstatus = () => {
    const [profile, setProfile] = useState([]);
    const [filteredProfile, setFilteredProfile] = useState([]);

    const fetchData = () => {
        axios.get('http://192.168.1.150:3000/auth/profile')
            .then(result => {
                if (result.data.Status) {
                    setProfile(result.data.Result);
                    // Filter profiles based on specific names
                    const namesToFilter = ["Aniket Sharma", "Tanisha Roy", "Sumit Potraj", "Kiran Gaikwad", "Anuradha Manda"];
                    const filtered = result.data.Result.filter(emp => namesToFilter.includes(emp.name));
                    setFilteredProfile(filtered);
                } else {
                    alert(result.data.Error);
                }
            })
            .catch(err => console.log(err));
    }

    useEffect(() => {
        fetchData();
        const interval = setInterval(fetchData, 2000);
        return () => clearInterval(interval); // Cleanup interval on component unmount
    }, []);

    const activeCount = filteredProfile.filter(c => c.status === 'Active').length;
    const inActiveCount = filteredProfile.filter(c => c.status === 'Inactive').length;
    const breakCount = filteredProfile.filter(c => c.status === 'Tea Break' ||
        c.status === 'Lunch Break' || c.status === 'Emergency Break').length;

    const tableStyle = {
        width: '100%',
        borderCollapse: 'collapse',
        marginTop: '20px',
        boxShadow: '0 0 20px rgba(0, 0, 0, 0.1)',
    };

    const thStyle = {
        backgroundColor: '#c66fe0',
        borderBottom: '2px solid #dee2e6',
        padding: '12px 15px',
        textAlign: 'left',
    };

    const tdStyle = {
        padding: '12px 15px',
        textAlign: 'left',
    };

    const inactiveRowStyle = {
        backgroundColor: '#ffcccc', // Light red background for inactive rows
    };

    const activeStyle = {
        backgroundColor: '#daf7d3', // Light green background for active rows
    };

    const breakStyle = {
        backgroundColor: 'yellow', // Light yellow background for break rows
    };

    const navigate = useNavigate(); // Hook for navigation
    const [navOpen, setNavOpen] = useState(false); // State to handle sidebar visibility

    const toggleNav = () => {
        setNavOpen(!navOpen);
    };

    const handleNavClick = (path) => {
        navigate(path);
        setNavOpen(false); // Close the menu on navigation
    };

    return (
        <div>
            <header className="header11">
                <div><img src={img1} alt="Logo" /></div>
                <div className="header-left22">
                    <span className="header-title33">REGA </span>
                </div>
                <div className="header-center44">
                    <h1 className='h11'>Employees Status</h1>
                </div>
            </header>
            <div className='nav'>
                <nav className="sidebar">
                    <button
                        className="menu-icon" onClick={toggleNav}
                        style={{ borderRadius: '50%', padding: '4px', borderColor: 'white' }}
                    >⋮ ☰
                    </button>
                    {navOpen && (
                        <ul className="nav-list1">
                            <li className="nav-item">
                                <Link to='/ashukhanprofile' className="nav-link">Profile</Link>
                            </li>
                            <li className="nav-item">
                                <Link to='/ashukhanstatus' className="nav-link"
                                    style={{ background: '#a623ce', borderRadius: '20px' }}>Employees</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/ashukhanpayroll" className="nav-link">Payroll</Link>
                            </li>
                            <li className="nav-item">
                                <Link to='/ashukhanattendance' className="nav-link">Attendance</Link>
                            </li>
                            <li className="nav-item">
                                <Link to='/ashukhanapplication' className="nav-link">Application Letter</Link>
                            </li>
                            <li className='nav-item'>
                                <Link to={'/'} className="nav-link">Logout</Link>
                            </li>
                        </ul>
                    )}
                    <div className='copy-nav'>
                        <ul className="nav-list">
                            <li className="nav-item">
                                <Link to='/ashukhanprofile' className="nav-link">Profile</Link>
                            </li>
                            <li className="nav-item">
                                <Link to='/ashukhanstatus' className="nav-link"
                                    style={{ background: '#a623ce', borderRadius: '20px' }}>Employees</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/ashukhanpayroll" className="nav-link">Payroll</Link>
                            </li>
                            <li className="nav-item">
                                <Link to='/ashukhanattendance' className="nav-link">Attendance</Link>
                            </li>
                            <li className="nav-item">
                                <Link to='/ashukhanapplication' className="nav-link">Application Letter</Link>
                            </li>
                            <li className='nav-item'>
                                <Link to={'/'} className="nav-link">Logout</Link>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
            <div className='real-main'>
                <main style={{
                    padding: '20px',
                    display: 'grid',
                    gridTemplateColumns: 'repeat(3, 1fr)',
                    gridTemplateRows: 'repeat(2, auto)',
                    gap: '20px',
                    background: '#e7e7e7',
                    borderRadius: '10px',
                    boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
                    marginTop: '30px',
                    color: '#333',
                    fontFamily: '"Roboto", sans-serif',
                }}>
                    <div style={{
                        background: '#daf7d3',
                        padding: '20px',
                        borderRadius: '10px',
                        boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
                        textAlign: 'center',
                        gridColumn: 'span 1', // Span only 1 column
                    }}>
                        <h1 style={{
                            fontSize: '24px',
                            color: '#2c3e50',
                            marginBottom: '10px',
                            fontWeight: '600'
                        }}>Active Employee</h1>
                        <p style={{
                            fontSize: '32px',
                            color: 'green',
                            fontWeight: '700'
                        }}>{activeCount}</p>
                    </div>
                    <div style={{
                        background: '#ffcccc',
                        padding: '20px',
                        borderRadius: '10px',
                        boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
                        textAlign: 'center',
                        gridColumn: 'span 1', // Span only 1 column
                    }}>
                        <h1 style={{
                            fontSize: '24px',
                            color: '#2c3e50',
                            marginBottom: '10px',
                            fontWeight: '600'
                        }}>In-active Employee</h1>
                        <p style={{
                            fontSize: '28px',
                            color: 'red',
                            fontWeight: '700'
                        }}>{inActiveCount}</p>
                    </div>
                    <div style={{
                        background: '#ffdef9',
                        padding: '20px',
                        borderRadius: '10px',
                        boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
                        textAlign: 'center',
                        gridColumn: 'span 1', // Span only 1 column
                    }}>
                        <h1 style={{
                            fontSize: '24px',
                            color: '#2c3e50',
                            marginBottom: '10px',
                            fontWeight: '600'
                        }}>Employees on Break</h1>
                        <p style={{
                            fontSize: '28px',
                            color: '#c0392b',
                            fontWeight: '700'
                        }}>{breakCount}</p>
                    </div>
                    <div style={{
                        gridColumn: 'span 3', // Span across all 3 columns
                    }}>
                        <table style={tableStyle}>
                            <thead>
                                <tr>
                                    <th style={thStyle}>Sr.no</th>
                                    <th style={thStyle}>Employee Name</th>
                                    <th style={thStyle}>Designation</th>
                                    <th style={thStyle}>Current Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                {filteredProfile.map((c, index) => {
                                    let rowStyle = null; // Default to even row style

                                    if (c.status === "Inactive") {
                                        rowStyle = inactiveRowStyle;
                                    } else if (c.status === "Active") {
                                        rowStyle = activeStyle;
                                    } else if (c.status === "Tea Break" || c.status === "Lunch Break" || c.status === "Emergency Break") {
                                        rowStyle = breakStyle;
                                    }

                                    return (
                                        <tr key={c.id} style={rowStyle}>
                                            <td style={tdStyle}><strong>{index + 1}</strong></td>
                                            <td style={tdStyle}><strong>{c.name}</strong></td>
                                            <td style={tdStyle}><strong>{c.department}</strong></td>
                                            <td style={tdStyle}><strong>{c.status}</strong></td>
                                        </tr>
                                    );
                                })}
                            </tbody>
                        </table>
                    </div>
                </main>
            </div>
            <div className='copy-main'>
                {!navOpen && (
                    <main style={{
                        padding: '20px',
                        display: 'grid',
                        gridTemplateColumns: 'repeat(2, 2fr)',
                        gridTemplateRows: 'repeat(2, auto)',
                        gap: '20px',
                        background: '#e7e7e7',
                        borderRadius: '10px',
                        boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
                        marginTop: '30px',
                        color: '#333',
                        fontFamily: '"Roboto", sans-serif',
                    }}>
                        <div style={{
                            background: '#daf7d3',
                            padding: '20px',
                            borderRadius: '10px',
                            boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
                            textAlign: 'center',
                            gridColumn: 'span 1', // Span only 1 column
                        }}>
                            <h1 style={{
                                fontSize: '24px',
                                color: '#2c3e50',
                                marginBottom: '10px',
                                fontWeight: '600'
                            }}>Active Employee</h1>
                            <p style={{
                                fontSize: '32px',
                                color: 'green',
                                fontWeight: '700'
                            }}>{activeCount}</p>
                        </div>
                        <div style={{
                            background: '#ffcccc',
                            padding: '20px',
                            borderRadius: '10px',
                            boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
                            textAlign: 'center',
                            gridColumn: 'span 1', // Span only 1 column
                        }}>
                            <h1 style={{
                                fontSize: '24px',
                                color: '#2c3e50',
                                marginBottom: '10px',
                                fontWeight: '600'
                            }}>In-active Employee</h1>
                            <p style={{
                                fontSize: '28px',
                                color: 'red',
                                fontWeight: '700'
                            }}>{inActiveCount}</p>
                        </div>
                        <div style={{
                            background: '#ffdef9',
                            padding: '20px',
                            borderRadius: '10px',
                            boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
                            textAlign: 'center',
                            gridColumn: 'span 2', // Span only 1 column
                        }}>
                            <h1 style={{
                                fontSize: '24px',
                                color: '#2c3e50',
                                marginBottom: '10px',
                                fontWeight: '600'
                            }}>Employees on Break</h1>
                            <p style={{
                                fontSize: '28px',
                                color: '#c0392b',
                                fontWeight: '700'
                            }}>{breakCount}</p>
                        </div>
                        <div style={{
                            gridColumn: 'span 3', // Span across all 3 columns
                        }}>
                            <table style={tableStyle}>
                                <thead>
                                    <tr>
                                        <th style={thStyle}>Sr.no</th>
                                        <th style={thStyle}>Employee Name</th>
                                        <th style={thStyle}>Designation</th>
                                        <th style={thStyle}>Current Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {filteredProfile.map((c, index) => {
                                        let rowStyle = null; // Default to even row style

                                        if (c.status === "Inactive") {
                                            rowStyle = inactiveRowStyle;
                                        } else if (c.status === "Active") {
                                            rowStyle = activeStyle;
                                        } else if (c.status === "Tea Break" || c.status === "Lunch Break" || c.status === "Emergency Break") {
                                            rowStyle = breakStyle;
                                        }

                                        return (
                                            <tr key={c.id} style={rowStyle}>
                                                <td style={tdStyle}><strong>{index + 1}</strong></td>
                                                <td style={tdStyle}><strong>{c.name}</strong></td>
                                                <td style={tdStyle}><strong>{c.department}</strong></td>
                                                <td style={tdStyle}><strong>{c.status}</strong></td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                    </main>
                )}
            </div>
        </div>
    );
}

export default employeesstatus;
