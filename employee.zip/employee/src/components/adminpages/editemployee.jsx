import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import img1 from './image/logo.png';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const Editemployee = () => {
  const [value, setValue] = useState({
    username: '',
    pwd: '',
    newname: '',
    newpassword: '',
    newdepartment: '',
  });

  const [error, setError] = useState('');

  const Navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const result = await axios.post('http://192.168.1.150:3000/auth/editemployee', value);
      if (result.data.Status) {
        Navigate('/adminemployee');
      } else {
        alert(result.data.Error);
      }
    } catch (err) {
      console.error('Error:', err);
    }
  };

  const handleChange = (e) => {
    setValue({ ...value, [e.target.name]: e.target.value });
  };

  const styles = {
    mainContent: {
      flex: '1',
      padding: '20px',
    },
    container: {
      maxWidth: '600px',
      margin: 'auto',
      padding: '20px',
      backgroundColor: '#fff',
      border: '1px solid #ddd',
      borderRadius: '8px',
      boxShadow: '0 0 20px rgba(0, 0, 0, 0.1)',
    },
    formGroup: {
      marginBottom: '15px',
    },
    label: {
      display: 'block',
      marginBottom: '5px',
    },
    formControl: {
      width: '100%',
      padding: '8px',
      fontSize: '14px',
      border: '3px solid #ccc',
      borderRadius: '4px',
    },
    btnPrimary: {
      backgroundColor: '#007bff',
      color: '#fff',
      border: 'none',
      padding: '10px 20px',
      cursor: 'pointer',
      borderRadius: '4px',
    },
    btnPrimaryHover: {
      backgroundColor: '#0056b3',
    },
    error: {
      color: 'red',
      marginTop: '5px',
    },
  };

  const navigate = useNavigate(); // Hook for navigation
  const [navOpen, setNavOpen] = useState(false); // State to handle sidebar visibility

  const toggleNav = () => {
    setNavOpen(!navOpen);
  };

  const handleNavClick = (path) => {
    navigate(path);
    setNavOpen(false); // Close the menu on navigation
  };

  return (
    <div>
      <header className="header11">
        <div>
          <img src={img1} alt="Logo" />
        </div>
        <div className="header-left22">
          <span className="header-title33">REGA </span>
        </div>
        <div className="header-center44" style={{marginLeft:'10px'}}>
          <h3 className='h11' ><div>Update Username & password</div></h3>
        </div>
      </header>
      <div className='nav'>
        <nav className="sidebar">
          <button
            className="menu-icon" onClick={toggleNav}
            style={{ borderRadius: '50%', padding: '4px', borderColor: 'white' }}
          >⋮ ☰
          </button>
          {navOpen && (
            <ul className="nav-list1">
              <li className="nav-item">
                <Link to="/adminview" className="nav-link">Dashboard</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminemployee' className="nav-link"
                  style={{ background: '#a623ce', borderRadius: '20px' }}>Employees</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminpayroll' className="nav-link">Payroll</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminaxispayroll' className="nav-link">Axis Record</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminattendance'} className="nav-link">Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminaxisattendance'} className="nav-link">Axis Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminapplication'} className="nav-link">Application</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/admin'} className="nav-link">Logout</Link>
              </li>
            </ul>
          )}
          <div className='copy-nav'>
            <ul className="nav-list">
              <li className="nav-item">
                <Link to="/adminview" className="nav-link">Dashboard</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminemployee' className="nav-link"
                  style={{ background: '#a623ce', borderRadius: '20px' }}>Employees</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminpayroll' className="nav-link">Payroll</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminaxispayroll' className="nav-link">Axis Record</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminattendance'} className="nav-link">Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminaxisattendance'} className="nav-link">Axis Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminapplication'} className="nav-link">Application</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/admin'} className="nav-link">Logout</Link>
              </li>
            </ul>
          </div>
        </nav>
      </div>
      <div>
        {!navOpen && (
          <main style={styles.mainContent}>
            <div className="container" style={styles.container}>
              <form onSubmit={handleSubmit}>
                <h1 style={styles.h1}>Enter All Details</h1>
                <div className="form-group" style={styles.formGroup}>
                  <label style={styles.label}>Username :</label>
                  <input
                    type="text"
                    id="username"
                    name="username"
                    className="form-control"
                    style={styles.formControl}
                    value={value.username}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="form-group" style={styles.formGroup}>
                  <label style={styles.label}>Password :</label>
                  <input
                    type="password"
                    id="pwd"
                    name="pwd"
                    className="form-control"
                    style={styles.formControl}
                    value={value.pwd}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="form-group" style={styles.formGroup}>
                  <label style={styles.label}>New Name :</label>
                  <input
                    type="text"
                    id="newname"
                    name="newname"
                    className="form-control"
                    style={styles.formControl}
                    value={value.newname}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="form-group" style={styles.formGroup}>
                  <label style={styles.label}>New Password :</label>
                  <input
                    type="password"
                    id="newpassword"
                    name="newpassword"
                    className="form-control"
                    style={styles.formControl}
                    value={value.newpassword}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="form-group" style={styles.formGroup}>
                  <label style={styles.label}>New Department :</label>
                  <input
                    type="text"
                    id="newdepartment"
                    name="newdepartment"
                    className="form-control"
                    style={styles.formControl}
                    value={value.newdepartment}
                    onChange={handleChange}
                    required
                  />
                </div>
                {error && <p style={styles.error}>{error}</p>}
                <button
                  type="submit"
                  className="btn btn-primary"
                  style={styles.btnPrimary}
                >
                  Submit
                </button>
              </form>
            </div>
          </main>
        )}
      </div>
    </div>
  );
};

export default Editemployee;
