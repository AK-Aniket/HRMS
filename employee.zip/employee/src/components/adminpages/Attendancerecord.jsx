import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import img1 from './image/logo.png';
import axios from 'axios';
import * as XLSX from 'xlsx';

const Attendancerecord = () => {
  const [attendance, setAttendance] = useState([]);
  const [filteredAttendance, setFilteredAttendance] = useState([]);
  const [searchName, setSearchName] = useState('');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');

  useEffect(() => {
    const fetchAttendanceData = () => {
      axios.get('http://192.168.1.150:3000/auth/attendancerecord')
        .then(result => {
          if (result.data.Status) {
            setAttendance(result.data.Result);
            setFilteredAttendance(result.data.Result);
          } else {
            alert(result.data.Error);
          }
        })
        .catch(err => console.log('Fetch error:', err));
    };

    fetchAttendanceData();
  }, []);

  const filterRecords = () => {
    const filtered = attendance.filter(record => {
      const recordDate = new Date(record.date);
      const from = new Date(fromDate);
      const to = new Date(toDate);

      return (
        record.Name.toLowerCase().includes(searchName.toLowerCase()) &&
        (!fromDate || recordDate >= from) &&
        (!toDate || recordDate <= to)
      );
    });
    setFilteredAttendance(filtered);
  };

  const formatTime = (time) => {
    if (!time) return '';
    const [hour, minute] = time.split(':').map(Number);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const formattedHour = hour % 12 || 12;
    return `${formattedHour}:${minute.toString().padStart(2, '0')} ${ampm}`;
  };

  const parseDuration = (duration) => {
    if (!duration) return 0;
    const [hours = 0, minutes = 0, seconds = 0] = duration.split(':').map(Number);
    return (hours * 3600) + (minutes * 60) + seconds; // Convert to total seconds
  };

  const formatDuration = (totalSeconds) => {
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = Math.floor(totalSeconds % 60);
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  const calculateTotalBreak = (record) => {
    const teaBreak = parseDuration(record['tea_break']);
    const lunchBreak = parseDuration(record['lunch_break']);
    const teaBreak2 = parseDuration(record['tea_break2']);
    const emergency = parseDuration(record['emergency']);
    const totalBreak = teaBreak + lunchBreak + teaBreak2 + emergency;
    return formatDuration(totalBreak);
  };

  const tableStyles = {
    width: '100%',
    borderCollapse: 'collapse',
    marginTop: '20px',
    boxShadow: '0 0 10px rgba(0, 0, 0, 0.2)',
    border: '1px solid #ddd',
    borderRadius: '8px',
    overflow: 'hidden',
  };

  const thStyles = {
    border: '1px solid #ddd',
    padding: '12px 15px',
    textAlign: 'left',
    backgroundColor: '#6c5b7b',
    color: '#fff',
    fontWeight: 'bold',
    textTransform: 'uppercase',
  };

  const tdStyles = {
    border: '1px solid #3a3a3a',
    padding: '12px 15px',
    textAlign: 'left',
  };

  const rowStyles = {
    transition: 'background-color 0.3s ease, transform 0.3s ease',
  };

  const oddRowStyles = {
    backgroundColor: '#f9f9f9',
  };

  const evenRowStyles = {
    backgroundColor: '#ffffff',
  };

  const hoverRowStyles = {
    backgroundColor: '#f1f1f1',
    transform: 'scale(1.02)',
  };

  const dateColumnStyles = {
    width: '150px',
  };

  const handleDownload = () => {
    const ws = XLSX.utils.json_to_sheet(filteredAttendance.map(record => ({
      Name: record['Name'],
      Date: record['date'],
      'Punch In Time': formatTime(record['punch_In']),
      'Punch Out Time': formatTime(record['punch_out']),
      'Morning Tea Break': record['tea_break'],
      'Lunch Break Time': record['lunch_break'],
      'Evening Tea Break': record['tea_break2'],
      'Emergency Break': record['emergency'],
      'Total Break': calculateTotalBreak(record),
      'Grand Total': record['Working'],
    })));

    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Attendance Records');

    XLSX.writeFile(wb, 'Attendance_Records.xlsx');
  };

  const navigate = useNavigate(); // Hook for navigation
  const [navOpen, setNavOpen] = useState(false); // State to handle sidebar visibility

  const toggleNav = () => {
    setNavOpen(!navOpen);
  };

  const handleNavClick = (path) => {
    navigate(path);
    setNavOpen(false); // Close the menu on navigation
  };

  return (
    <div>
      <header className="header11">
        <div><img src={img1} alt="Logo" /></div>
        <div className="header-left22">
          <span className="header-title33">REGA</span>
        </div>
        <div className="header-center44">
          <h1 className='h1'>Admin  View</h1>
        </div>
      </header>
      <div className='nav'>
        <nav className="sidebar">
          <button
            className="menu-icon" onClick={toggleNav}
            style={{ borderRadius: '50%', padding: '4px', borderColor: 'white' }}
          >⋮ ☰
          </button>
          {navOpen && (
            <ul className="nav-list1">
              <li className="nav-item">
                <Link to="/adminview" className="nav-link">Dashboard</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminemployee' className="nav-link">Employees</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminpayroll' className="nav-link">Payroll</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminaxispayroll' className="nav-link">Axis Record</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminattendance'} className="nav-link"
                  style={{ background: '#a623ce', borderRadius: '20px' }}>Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminaxisattendance'} className="nav-link">Axis Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminapplication'} className="nav-link">Application</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/admin'} className="nav-link">Logout</Link>
              </li>
            </ul>
          )}
          <div className='copy-nav'>
            <ul className="nav-list">
              <li className="nav-item">
                <Link to="/adminview" className="nav-link">Dashboard</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminemployee' className="nav-link">Employees</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminpayroll' className="nav-link">Payroll</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminaxispayroll' className="nav-link">Axis Record</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminattendance'} className="nav-link"
                  style={{ background: '#a623ce', borderRadius: '20px' }}>Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminaxisattendance'} className="nav-link">Axis Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminapplication'} className="nav-link">Application</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/admin'} className="nav-link">Logout</Link>
              </li>
            </ul>
          </div>
        </nav>
      </div>
      <div>
        {!navOpen && (
          <main>
            <div className="search-container">
              <input
                type="text"
                placeholder="Search by name"
                value={searchName}
                onChange={(e) => setSearchName(e.target.value)}
                className="search-input"
              />
              <input
                style={{ marginLeft: '10px' }}
                type="date"
                value={fromDate}
                onChange={(e) => setFromDate(e.target.value)}
                className="search-input"
              />
              <input
                style={{ marginLeft: '10px' }}
                type="date"
                value={toDate}
                onChange={(e) => setToDate(e.target.value)}
                className="search-input"
              />
              <button onClick={filterRecords} style={{
                marginLeft: '10px',
                backgroundColor: 'yellowgreen',
                padding: '0px 10px',
                borderRadius: '6px'
              }}>
                Search
              </button>
              <button onClick={handleDownload} style={{
                marginLeft: '10px',
                backgroundColor: 'blue',
                color: 'white',
                padding: '0px 10px',
                borderRadius: '6px'
              }}>
                Download
              </button>
            </div>
            <br />
            <div className="attendance-table">
              <table style={tableStyles}>
                <thead>
                  <tr>
                    <th style={thStyles}>Name</th>
                    <th style={{ ...thStyles, ...dateColumnStyles }}>Date</th>
                    <th style={thStyles}>Punch In Time</th>
                    <th style={thStyles}>Punch Out Time</th>
                    <th style={thStyles}>Morning Tea Break</th>
                    <th style={thStyles}>Lunch Break</th>
                    <th style={thStyles}>Evening Tea Break</th>
                    <th style={thStyles}>Emergency Break</th>
                    <th style={thStyles}>Total Break</th>
                    <th style={thStyles}>Grand Total</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredAttendance.map((record, index) => (
                    <tr
                      key={index}
                      style={{
                        ...rowStyles,
                        ...(index % 2 === 0 ? evenRowStyles : oddRowStyles),
                      }}
                      onMouseEnter={e => e.currentTarget.style.backgroundColor = hoverRowStyles.backgroundColor}
                      onMouseLeave={e => e.currentTarget.style.backgroundColor = index % 2 === 0 ? evenRowStyles.backgroundColor : oddRowStyles.backgroundColor}
                    >
                      <td style={tdStyles}>{record['Name']}</td>
                      <td style={tdStyles}>{record['date']}</td>
                      <td style={tdStyles}>{formatTime(record['punch_In'])}</td>
                      <td style={tdStyles}>{formatTime(record['punch_out'])}</td>
                      <td style={tdStyles}>{record['tea_break']}</td>
                      <td style={tdStyles}>{record['lunch_break']}</td>
                      <td style={tdStyles}>{record['tea_break2']}</td>
                      <td style={tdStyles}>{record['emergency']}</td>
                      <td style={tdStyles}>{calculateTotalBreak(record)}</td>
                      <td style={tdStyles}>{record['Working']}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </main>
        )}
      </div>
    </div>
  );
};

export default Attendancerecord;
