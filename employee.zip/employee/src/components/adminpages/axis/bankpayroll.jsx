import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import img1 from '../image/logo.png';
import axios from 'axios';
import * as XLSX from 'xlsx';

const bankpayroll = () => {
  const [payroll, setPayroll] = useState([]);
  const [filteredPayroll, setFilteredPayroll] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [editingIndex, setEditingIndex] = useState(null);
  const [editingRecord, setEditingRecord] = useState({});
  const [previousRecord, setPreviousRecord] = useState({});
  const [selectedRows, setSelectedRows] = useState(new Set());
  const [showSelection, setShowSelection] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    axios.get('http://192.168.1.150:3000/auth/adminaxispayroll')
      .then(result => {
        if (result.data.Status) {
          setPayroll(result.data.Result);
          setFilteredPayroll(result.data.Result);
        } else {
          alert(result.data.Error);
        }
      })
      .catch(err => console.error(err));
  }, []);

  const handleSearch = () => {
    const lowercasedSearchTerm = searchTerm.toLowerCase();
    const filtered = payroll.filter(record =>
      record['name'].toLowerCase().includes(lowercasedSearchTerm) ||
      record['date'].toLowerCase().includes(lowercasedSearchTerm) ||
      record['ID'].toLowerCase().includes(lowercasedSearchTerm)
    );
    setFilteredPayroll(filtered);
  };

  const handleInputChange = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleExport = () => {
    const ws = XLSX.utils.json_to_sheet(filteredPayroll);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Axis Payroll");
    XLSX.writeFile(wb, "AxisRecord.xlsx");
  };

  const startEditing = (index) => {
    setEditingIndex(index);
    const record = filteredPayroll[index];
    setEditingRecord(record);
    setPreviousRecord({
      date: record['date'],
      name: record['name']
    });
  };

  const handleDelete = () => {
    if (selectedRows.size === 0) {
      alert("No rows selected for deletion.");
      return;
    }

    setShowSelection(false);
    setIsDeleting(true);

    const slipnosToDelete = Array.from(selectedRows);

    axios.post('http://192.168.1.150:3000/auth/axisdelete', { slipnos: slipnosToDelete })
      .then(result => {
        if (result.data.Status) {
          return axios.get('http://192.168.1.150:3000/auth/adminaxispayroll');
        } else {
          throw new Error(result.data.Error);
        }
      })
      .then(result => {
        if (result.data.Status) {
          setPayroll(result.data.Result);
          setFilteredPayroll(result.data.Result);
          setSelectedRows(new Set());
          setShowSelection(false);
          setIsDeleting(false);
        } else {
          throw new Error(result.data.Error);
        }
      })
      .catch(err => {
        console.error(err);
        alert(err.message);
        setShowSelection(true);
        setIsDeleting(false);
      });
  };

  const handleEditChange = (e, key) => {
    setEditingRecord({
      ...editingRecord,
      [key]: e.target.value
    });
  };

  const calculateTotals = () => {
    return filteredPayroll.reduce((totals, record) => {
      totals.Micr += parseFloat(record['Micr']) || 0;
      totals.AccountNo += parseFloat(record['Account_no']) || 0;
      totals.AmountNo += parseFloat(record['Amount_no']) || 0;
      totals.DrawalName += parseFloat(record['Drawal_name']) || 0;
      return totals;
    }, { Micr: 0, AccountNo: 0, AmountNo: 0,DrawalName: 0 });
  };

  const totals = calculateTotals();

  const saveEdit = () => {
    const dataToSend = {
      newname: editingRecord['name'],
      id: editingRecord['ID'],
      newdate: editingRecord['date'],
      accountno: editingRecord['Account_no'],
      Micr: editingRecord['Micr'],
      amountno: editingRecord['Amount_no'],
      drawalname: editingRecord['Drawal_name'],
      date: previousRecord['date'],
      name: previousRecord['name']
    };

    axios.post('http://192.168.1.150:3000/auth/axisedit', dataToSend)
      .then(result => {
        if (result.data.Status) {
          return axios.get('http://192.168.1.150:3000/auth/adminaxispayroll');
        } else {
          throw new Error(result.data.Error);
        }
      })
      .then(result => {
        if (result.data.Status) {
          setPayroll(result.data.Result);
          setFilteredPayroll(result.data.Result);
          setEditingIndex(null);
          setEditingRecord({});
        } else {
          throw new Error(result.data.Error);
        }
      })
      .catch(err => {
        console.error(err);
        alert(err.message);
      });
  };

  const tableStyles = {
    width: '100%',
    borderCollapse: 'collapse',
    marginTop: '20px',
    boxShadow: '0 0 10px rgba(0, 0, 0, 0.2)',
    border: '1px solid #ddd',
    borderRadius: '8px',
    overflow: 'hidden',
  };

  const thStyles = {
    border: '1px solid #ddd',
    padding: '12px 15px',
    textAlign: 'left',
    backgroundColor: '#6c5b7b',
    color: '#fff',
    fontWeight: 'bold',
    textTransform: 'uppercase',
  };

  const tdStyles = {
    border: '1px solid #ddd',
    padding: '12px 15px',
  };

  const rowStyles = {
    transition: 'background-color 0.3s ease, transform 0.3s ease',
  };

  const oddRowStyles = {
    backgroundColor: '#f9f9f9',
  };

  const evenRowStyles = {
    backgroundColor: '#ffffff',
  };

  const hoverRowStyles = {
    backgroundColor: '#f1f1f1',
    transform: 'scale(1.01)',
  };

  const [navOpen, setNavOpen] = useState(false); // State to handle sidebar visibility

  const toggleNav = () => {
    setNavOpen(!navOpen);
  };

  const handleNavClick = (path) => {
    navigate(path);
    setNavOpen(false); // Close the menu on navigation
  };

  return (
    <div>
      <header className="header11">
        <div><img src={img1} alt="Logo" /></div>
        <div className="header-left22">
          <span className="header-title33">REGA </span>
        </div>
        <div className="header-center44">
          <h1 className='h1'>Payroll</h1>
        </div>
      </header>
      <div className='nav'>
        <nav className="sidebar">
          <button
            className="menu-icon" onClick={toggleNav}
            style={{ borderRadius: '50%', padding: '4px', borderColor: 'white' }}
          >⋮ ☰
          </button>
          {navOpen && (
            <ul className="nav-list1">
              <li className="nav-item">
                <Link to="/adminview" className="nav-link">Dashboard</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminemployee' className="nav-link">Employees</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminpayroll' className="nav-link">Payroll</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminaxispayroll' className="nav-link"
                  style={{ background: '#a623ce', borderRadius: '20px 20px 20px 20px' }}>Axis Record</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminattendance'} className="nav-link">Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminaxisattendance'} className="nav-link">Axis Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminapplication'} className="nav-link">Application</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/admin'} className="nav-link">Logout</Link>
              </li>
            </ul>
          )}
          <div className='copy-nav'>
            <ul className="nav-list">
              <li className="nav-item">
                <Link to="/adminview" className="nav-link">Dashboard</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminemployee' className="nav-link">Employees</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminpayroll' className="nav-link">Payroll</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminaxispayroll' className="nav-link"
                  style={{ background: '#a623ce', borderRadius: '20px 20px 20px 20px' }}>Axis Record</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminattendance'} className="nav-link">Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminaxisattendance'} className="nav-link">Axis Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminapplication'} className="nav-link">Application</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/admin'} className="nav-link">Logout</Link>
              </li>
            </ul>
          </div>
        </nav>
        {!navOpen && (
          <main>
            <div className="payroll-table">
              <div style={{ marginBottom: '20px' }}>
                <button className="btn btn-primary" onClick={() => navigate('/axisadd')} style={{ marginRight: '10px' }}>Add Record</button>
                <button
                  className="btn btn-info"
                  onClick={() => setShowSelection(true)} // Show selection checkboxes
                  style={{ marginRight: '10px' }}
                >
                  Delete
                </button>
                <button className="btn btn-success" onClick={handleExport}>Download Payroll</button>
              </div>
              <div style={{ marginBottom: '20px' }}>
                <input
                  type="text"
                  value={searchTerm}
                  onChange={handleInputChange}
                  placeholder="Search by Salary Slip No or Employee Name"
                  style={{
                    padding: '8px',
                    fontSize: '16px',
                    border: '1px solid #ddd',
                    borderRadius: '4px',
                    width: '250px',
                  }}
                />
                <button
                  className="btn btn-success ml-2"
                  onClick={handleSearch}
                  style={{ padding: '8px 16px', fontSize: '16px', margin: '10px' }}
                >
                  Search
                </button>
              </div>
              <div className='payroll2'>
                <table style={tableStyles}>
                  <thead>
                    <tr>
                      {showSelection && (
                        <th style={thStyles}>
                          <input
                            type="checkbox"
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedRows(new Set(filteredPayroll.map(record => record['ID'])));
                              } else {
                                setSelectedRows(new Set());
                              }
                            }}
                          />
                        </th>
                      )}
                      <th style={thStyles}>ID</th>
                      <th style={thStyles}>Date</th>
                      <th style={thStyles}>Name</th>
                      <th style={thStyles}>Micr NO</th>
                      <th style={thStyles}>Account No</th>
                      <th style={thStyles}>Amount No</th>
                      <th style={thStyles}>Drawal Name</th>
                      <th style={thStyles}>Total Entry</th> {/* New Column */}
                      <th style={thStyles}>Edit</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredPayroll.map((c, index) => {
                      // Calculate row-specific total
                      const rowTotal = (parseFloat(c['Micr']) || 0) + (parseFloat(c['Account_no']) || 0) + (parseFloat(c['Amount_no']) || 0)+(parseFloat(c['Drawal_name']) || 0);
                      return (
                        <tr
                          key={index}
                          style={{
                            ...rowStyles,
                            ...(index % 2 === 0 ? evenRowStyles : oddRowStyles),
                          }}
                          onMouseEnter={e => e.currentTarget.style.backgroundColor = hoverRowStyles.backgroundColor}
                          onMouseLeave={e => e.currentTarget.style.backgroundColor = index % 2 === 0 ? evenRowStyles.backgroundColor : oddRowStyles.backgroundColor}
                        >
                          {showSelection && (
                            <td style={tdStyles}>
                              <input
                                type="checkbox"
                                checked={selectedRows.has(c['ID'])}
                                onChange={() => {
                                  const newSelectedRows = new Set(selectedRows);
                                  if (newSelectedRows.has(c['ID'])) {
                                    newSelectedRows.delete(c['ID']);
                                  } else {
                                    newSelectedRows.add(c['ID']);
                                  }
                                  setSelectedRows(newSelectedRows);
                                }}
                              />
                            </td>
                          )}
                          <td style={tdStyles}>
                            {editingIndex === index ? (
                              <input
                                type="text"
                                value={editingRecord['ID'] || ''}
                                onChange={(e) => handleEditChange(e, 'ID')}
                              />
                            ) : (
                              c['ID']
                            )}
                          </td>
                          <td style={tdStyles}>
                            {editingIndex === index ? (
                              <input
                                type="text"
                                value={editingRecord['date'] || ''}
                                onChange={(e) => handleEditChange(e, 'date')}
                              />
                            ) : (
                              c['date']
                            )}
                          </td>
                          <td style={tdStyles}>
                            {editingIndex === index ? (
                              <input
                                type="text"
                                value={editingRecord['name'] || ''}
                                onChange={(e) => handleEditChange(e, 'name')}
                              />
                            ) : (
                              c['name']
                            )}
                          </td>
                          <td style={tdStyles}>
                            {editingIndex === index ? (
                              <input
                                type="text"
                                value={editingRecord['Micr'] || ''}
                                onChange={(e) => handleEditChange(e, 'Micr')}
                              />
                            ) : (
                              c['Micr']
                            )}
                          </td>
                          <td style={tdStyles}>
                            {editingIndex === index ? (
                              <input
                                type="text"
                                value={editingRecord['Account_no'] || ''}
                                onChange={(e) => handleEditChange(e, 'Account_no')}
                              />
                            ) : (
                              c['Account_no']
                            )}
                          </td>
                          <td style={tdStyles}>
                            {editingIndex === index ? (
                              <input
                                type="text"
                                value={editingRecord['Amount_no'] || ''}
                                onChange={(e) => handleEditChange(e, 'Amount_no')}
                              />
                            ) : (
                              c['Amount_no']
                            )}
                          </td>
                          <td style={tdStyles}>
                            {editingIndex === index ? (
                              <input
                                type="text"
                                value={editingRecord['Drawal_name'] || ''}
                                onChange={(e) => handleEditChange(e, 'Drawal_name')}
                              />
                            ) : (
                              c['Drawal_name']
                            )}
                          </td>
                          <td style={tdStyles}>
                            {rowTotal.toFixed(2)} {/* Display row-specific total */}
                          </td>
                          <td style={tdStyles}>
                            {editingIndex === index ? (
                              <button className="btn btn-success" onClick={saveEdit}>Save</button>
                            ) : (
                              <button className="btn btn-info" onClick={() => startEditing(index)}>Edit</button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              {showSelection && (
                <button className="btn btn-danger" onClick={handleDelete} disabled={isDeleting}>
                  {isDeleting ? 'Deleting...' : 'Confirm Delete'}
                </button>
              )}
            </div>
          </main>
        )}
      </div>
    </div>
  );
};

export default bankpayroll;
