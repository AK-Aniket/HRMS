import React, { useState, useEffect } from 'react';
import { Link, redirect, useNavigate } from 'react-router-dom';
import img1 from './image/logo.png';
import axios from 'axios';
import '@fortawesome/fontawesome-free/css/all.min.css';

const Employees = () => {
  const [profile, setProfile] = useState([]);
  const [isPasswordChangeVisible, setIsPasswordChangeVisible] = useState(false);
  const [changePassword, setChangePassword] = useState({
    oldpassword: '',
    newpassword: '',
    confirmNewpassword: ''
  });
  const [passwordValidationError, setPasswordValidationError] = useState('');
  const [passwordsMatch, setPasswordsMatch] = useState(true);
  const [error, setError] = useState('');

  const Navigate = useNavigate();

  const validatePassword = (password) => {
    const minLength = 8;
    const hasUpperCase = /[A-Z]/.test(password);
    const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);
    return password.length >= minLength && hasUpperCase && hasSpecialChar;
  };

  useEffect(() => {
    setPasswordsMatch(changePassword.newpassword === changePassword.confirmNewpassword);
    if (changePassword.newpassword && !validatePassword(changePassword.newpassword)) {
      setPasswordValidationError('Password must be at least 8 characters long, include one uppercase letter, and one special character.');
    } else {
      setPasswordValidationError('');
    }
  }, [changePassword.newpassword, changePassword.confirmNewpassword]);

  const handleChangePassword = async (e) => {
    e.preventDefault();
    if (!passwordsMatch) {
      setError('New password and confirm password do not match');
      return;
    }
    if (passwordValidationError) {
      setError(passwordValidationError);
      return;
    }
    try {
      const result = await axios.post('http://192.168.1.150:3000/auth/adminpassword', {
        ...changePassword,
        username: 'rega@rega.com' // Replace with the actual username if needed
      });
      if (result.data.Status) {
        alert('Password changed successfully');
        setChangePassword({
          oldpassword: '',
          newpassword: '',
          confirmNewpassword: ''
        });
        setIsPasswordChangeVisible(false);
        setError('');
      } else {
        setError(result.data.Error);
      }
    } catch (err) {
      console.error('Error:', err);
      setError('An error occurred while changing the password.');
    }
  };

  const handleDelete = (username) => {
    if (username) {
      // Show confirmation dialog
      const userConfirmed = window.confirm("Are you sure you want to delete " + username + "?");

      if (userConfirmed) {
        // User confirmed the delete action
        axios.post('http://192.168.1.150:3000/auth/deleteprofile', { username: username })
          .then(response => {
            // Handle success
            alert("Deleted successfully");
          })
          .catch(error => {
            // Handle error
            alert("Error deleting record: " + error.message);
          });
      } else {
        // User canceled the action
        alert("Delete action canceled.");
      }
    } else {
      alert('Error fetching record.');
    }
  }



  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setChangePassword(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const fetchProfile = async () => {
    axios.get('http://192.168.1.150:3000/auth/profile')
      .then(result => {
        if (result.data.Status) {
          setProfile(result.data.Result);
        } else {
          alert(result.data.Error);
        }
      })
      .catch(err => console.log(err));
  }

  useEffect(() => {

    fetchProfile(); // Fetch profile initially
    const interval = setInterval(() => {
      fetchProfile(); // Fetch profile periodically
    }, 2000);

    // Clean up interval on component unmount
    return () => clearInterval(interval);
  }, []);

  const handleButtonClick = (username) => {
    localStorage.setItem('username2', username)

    if (username === 'Aniket.Sharma@regaenterprises.com') {
      Navigate('/aniket');
    } else if (username === 'Tanisha.Roy@regaenterprises.com') {
      Navigate('/tanisharoy');
    } else if (username === 'Bikas.Majumdar@regaenterprises.com') {
      Navigate('/bikas');
    } else if (username === 'Ashu.Khan@regaenterprises.com') {
      Navigate('/ashukhan');
    } else if (username === 'Sumit.Potraj@regaenterprises.com') {
      Navigate('/sumit');
    } else {
      Navigate('/demo');
    }
  };

  const handleButtonClick2 = (username) => {

    localStorage.setItem('username2', username)

    if (username === 'Aniket.Sharma@regaenterprises.com') {
      Navigate('/aniketpro');
    } else if (username === 'Tanisha.Roy@regaenterprises.com') {
      Navigate('/tanishapro');
    } else if (username === 'Sumit.Potraj@regaenterprises.com') {
      Navigate('/sumitpro');
    } else if (username === 'Bikas.Majumdar@regaenterprises.com') {
      Navigate('/bikaspro');
    } else if (username === 'Ashu.Khan@regaenterprises.com') {
      Navigate('/ashukhanpro');
    } else {
      Navigate('/demopro');
    }
  };

  const tableStyle = {
    width: '100%',
    borderCollapse: 'collapse',
    marginTop: '20px',
    boxShadow: '0 0 20px rgba(0, 0, 0, 0.1)',
  };

  const thStyle = {
    backgroundColor: '#f8f9fa',
    borderBottom: '2px solid #dee2e6',
    padding: '8px 10px',
    textAlign: 'left',
  };

  const tdStyle = {
    padding: '8px 10px',
    textAlign: 'left',
  };

  const evenRowStyle = {
    backgroundColor: '#f2f2f2',
  };

  const navigate = useNavigate(); // Hook for navigation
  const [navOpen, setNavOpen] = useState(false); // State to handle sidebar visibility

  const toggleNav = () => {
    setNavOpen(!navOpen);
  };

  const handleNavClick = (path) => {
    navigate(path);
    setNavOpen(false); // Close the menu on navigation
  };

  return (
    <div>
      <header className="header11">
        <div><img src={img1} alt="Logo" /></div>
        <div className="header-left22">
          <span className="header-title33">REGA</span>
        </div>
        <div className="header-center44">
          <h1 className='h11'>Employees  Record</h1>
        </div>
      </header>
      <div className='nav'>
        <nav className="sidebar">
          <button
            className="menu-icon" onClick={toggleNav}
            style={{ borderRadius: '50%', padding: '4px', borderColor: 'white' }}
          >⋮ ☰
          </button>
          {navOpen && (
            <ul className="nav-list1">
              <li className="nav-item">
                <Link to="/adminview" className="nav-link">Dashboard</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminemployee' className="nav-link"
                  style={{ background: '#a623ce', borderRadius: '20px' }}>Employees</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminpayroll' className="nav-link">Payroll</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminaxispayroll' className="nav-link">Axis Record</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminattendance'} className="nav-link">Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminaxisattendance'} className="nav-link">Axis Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminapplication'} className="nav-link">Application</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/admin'} className="nav-link">Logout</Link>
              </li>
            </ul>
          )}
          <div className='copy-nav'>
            <ul className="nav-list">
              <li className="nav-item">
                <Link to="/adminview" className="nav-link">Dashboard</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminemployee' className="nav-link"
                  style={{ background: '#a623ce', borderRadius: '20px' }}>Employees</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminpayroll' className="nav-link">Payroll</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminaxispayroll' className="nav-link">Axis Record</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminattendance'} className="nav-link">Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminaxisattendance'} className="nav-link">Axis Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminapplication'} className="nav-link">Application</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/admin'} className="nav-link">Logout</Link>
              </li>
            </ul>
          </div>
        </nav>
      </div>
      <div>
        {!navOpen && (
          <main>
            <button
              onClick={() => Navigate('/Editattendance')}
              style={{
                backgroundColor: '#4CAF50',
                border: 'none',
                color: 'white',
                padding: '10px 20px',
                textAlign: 'center',
                textDecoration: 'none',
                display: 'inline-block',
                fontSize: '16px',
                margin: '4px 2px',
                cursor: 'pointer',
                borderRadius: '8px'
              }}
            >
              Edit Record
            </button>
            <button
              onClick={() => setIsPasswordChangeVisible(!isPasswordChangeVisible)}
              style={{
                backgroundColor: '#4CAF50',
                border: 'none',
                color: 'white',
                padding: '10px 20px',
                textAlign: 'center',
                textDecoration: 'none',
                display: 'inline-block',
                fontSize: '16px',
                margin: '4px 2px',
                cursor: 'pointer',
                borderRadius: '8px'
              }}
            >
              Change Admin Password
            </button>
            <button
              onClick={() => {
                Navigate('/Addemployee')
              }}
              style={{
                backgroundColor: '#4CAF50',
                border: 'none',
                color: 'white',
                padding: '10px 20px',
                textAlign: 'center',
                textDecoration: 'none',
                display: 'inline-block',
                fontSize: '16px',
                margin: '4px 2px',
                cursor: 'pointer',
                borderRadius: '8px'
              }}
            >
              Add Employee
            </button>
            {isPasswordChangeVisible && (
              <div className="password-change-form" style={{ textAlign: 'center', marginTop: '20px' }}>
                {error && <p style={{ color: 'red' }}>{error}</p>}
                {passwordValidationError && <p style={{ color: 'red' }}>{passwordValidationError}</p>}
                <input
                  type="password"
                  name="oldpassword"
                  placeholder="Current Password"
                  value={changePassword.oldpassword}
                  onChange={handleInputChange} required
                />
                <input
                  type="password"
                  name="newpassword"
                  placeholder="New Password"
                  value={changePassword.newpassword}
                  onChange={handleInputChange} required
                />
                <input
                  type="password"
                  name="confirmNewpassword"
                  placeholder="Confirm New Password"
                  value={changePassword.confirmNewpassword}
                  onChange={handleInputChange} required
                />
                {!passwordsMatch && <p style={{ color: 'red' }}>Passwords do not match</p>}
                <button
                  onClick={handleChangePassword}
                  disabled={!passwordsMatch || passwordValidationError}
                  style={{ marginTop: '10px', padding: '10px', borderRadius: '5px', backgroundColor: '#277fc1', color: '#fff' }}
                >
                  Change Password
                </button>
              </div>
            )}
            <div className='table2'>
              <table style={tableStyle}>
                <thead>
                  <tr>
                    <th style={thStyle}>Sr.No</th>
                    <th style={thStyle}>Employee Name</th>
                    <th style={thStyle}>Employee Username</th>
                    <th style={thStyle}>Employee Password</th>
                    <th style={thStyle}>Employee Department</th>
                    <th style={thStyle}>Attendance</th>
                    <th style={thStyle}>Profile</th>
                    <th style={thStyle}>Delete</th>
                  </tr>
                </thead>
                <tbody>
                  {profile && profile.map((c, index) => (
                    <tr key={c.id} style={index % 2 === 0 ? evenRowStyle : null}>
                      <td style={tdStyle}>{index + 1}</td>
                      <td style={tdStyle}>{c.name}</td>
                      <td style={tdStyle}>{c.username}</td>
                      <td style={tdStyle}>{c.password}</td>
                      <td style={tdStyle}>{c.department}</td>
                      <td style={tdStyle}>
                        <button
                          onClick={() => handleButtonClick(c.username)}
                          style={{
                            marginLeft: '10px',
                            padding: '5px 10px',
                            backgroundColor: '#007bff',
                            color: 'white',
                            border: 'none',
                            borderRadius: '5px',
                            cursor: 'pointer',
                          }}
                        >
                          View
                        </button>
                      </td>
                      <td style={tdStyle}>
                        <button
                          onClick={() => handleButtonClick2(c.username)}
                          style={{
                            marginLeft: '10px',
                            padding: '5px 10px',
                            backgroundColor: '#007bff',
                            color: 'white',
                            border: 'none',
                            borderRadius: '5px',
                            cursor: 'pointer',
                          }}
                        >
                          View
                        </button>
                      </td>
                      <td style={tdStyle}>
                        <button
                          onClick={() => handleDelete(c.username)}
                          style={{
                            marginLeft: '10px',
                            padding: '5px',
                            backgroundColor: '#dc3545',
                            color: 'white',
                            border: 'none',
                            borderRadius: '5px',
                            cursor: 'pointer',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                          }}
                        >
                          <i className="fas fa-trash"></i>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </main>
        )}
      </div>
    </div>
  );
}

export default Employees;
