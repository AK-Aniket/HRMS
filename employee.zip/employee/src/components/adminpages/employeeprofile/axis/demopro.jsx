import React, { useState, useEffect } from 'react';
import '../../../style/attendance.css';
import { Link, useNavigate } from 'react-router-dom';
import img1 from '../image/logo.png';
import icon from '../image/icon.jpg';
import axios from 'axios';

const demopro = () => {

  const [image, setImage] = useState(null);
  const [aadharcard, setAadharCard] = useState(null);
  const [pancard, setPanCard] = useState(null);
  const [name, setName] = useState([]);
  const [qualification, setQualification] = useState(null);
  const [isZoomed, setIsZoomed] = useState(false);

  const username = localStorage.getItem('username2'); // Retrieve username from local storage

  useEffect(() => {
    const fetchImages = async () => {
      try {
        // Fetch Profile Image
        const profileResponse = await axios.get('http://192.168.1.150:3000/auth/profileimage', {
          params: { name: username }
        });
        if (profileResponse.data.Status) {
          setImage(profileResponse.data.imageDataUrl);
        }

        // Fetch Aadhar Card Image
        const aadharResponse = await axios.get('http://192.168.1.150:3000/auth/aadharcardimage', {
          params: { name: username }
        });
        if (aadharResponse.data.Status) {
          setAadharCard(aadharResponse.data.aadharcardDataUrl);
        }

        // Fetch Pan Card Image
        const panResponse = await axios.get('http://192.168.1.150:3000/auth/pancardimage', {
          params: { name: username }
        });
        if (panResponse.data.Status) {
          setPanCard(panResponse.data.pancardDataUrl);
        }

        // Fetch Qualification Image
        const qualificationResponse = await axios.get('http://192.168.1.150:3000/auth/qualificationimage', {
          params: { name: username }
        });
        if (qualificationResponse.data.Status) {
          setQualification(qualificationResponse.data.qualificationDataUrl);
        }
      } catch (error) {
        console.error('Error fetching images:', error);
      }
    };

    fetchImages();
  }, [username]);

  useEffect(() => {
    axios.get('http://192.168.1.150:3000/auth/profile')
      .then(result => {
        if (result.data.Status) {
          setName(result.data.Result);
        } else {
          alert(result.data.Error);
        }
      })
      .catch(err => console.log(err));
  }, []);

  const filteredData = name.filter((c) => c.username === username);

  const handleImageChange = async (e) => {
    const file = e.target.files[0];
    if (file) {
      const formData = new FormData();
      formData.append('image', file);
      formData.append('name', username);
      try {
        const result = await axios.post('http://192.168.1.150:3000/auth/profileimage', formData);
        if (result.data.Status) {
          setImage(URL.createObjectURL(file));
        } else {
          alert('Failed to upload profile image');
        }
      } catch (error) {
        console.error('Error uploading profile image:', error);
      }
    }
  };

  const handleAadharCard = async (e) => {
    const file = e.target.files[0];
    if (file) {
      const formData = new FormData();
      formData.append('aadharcard', file);
      formData.append('name', username);
      try {
        const result = await axios.post('http://192.168.1.150:3000/auth/aadharcardimage', formData);
        if (result.data.Status) {
          setAadharCard(URL.createObjectURL(file));
        } else {
          alert('Failed to upload Aadhar Card image');
        }
      } catch (error) {
        console.error('Error uploading Aadhar Card image:', error);
      }
    }
  };

  const handlePanCard = async (e) => {
    const file = e.target.files[0];
    if (file) {
      const formData = new FormData();
      formData.append('pancard', file);
      formData.append('name', username);
      try {
        const result = await axios.post('http://192.168.1.150:3000/auth/pancardimage', formData);
        if (result.data.Status) {
          setPanCard(URL.createObjectURL(file));
        } else {
          alert('Failed to upload Pan Card image');
        }
      } catch (error) {
        console.error('Error uploading Pan Card image:', error);
      }
    }
  };

  const handleQualification = async (e) => {
    const file = e.target.files[0];
    if (file) {
      const formData = new FormData();
      formData.append('qualification', file);
      formData.append('name', username);
      try {
        const result = await axios.post('http://192.168.1.150:3000/auth/qualificationimage', formData);
        if (result.data.Status) {
          setQualification(URL.createObjectURL(file));
        } else {
          alert('Failed to upload Qualification image');
        }
      } catch (error) {
        console.error('Error uploading Qualification image:', error);
      }
    }
  };

  const toggleZoom = () => {
    setIsZoomed(!isZoomed);
  };

  const navigate = useNavigate(); // Hook for navigation
  const [navOpen, setNavOpen] = useState(false); // State to handle sidebar visibility

  const toggleNav = () => {
    setNavOpen(!navOpen);
  };

  const handleNavClick = (path) => {
    navigate(path);
    setNavOpen(false); // Close the menu on navigation
  };

  return (
    <div>
      <header className="header11">
        <div><img src={img1} alt="Logo" /></div>
        <div className="header-left22">
          <span className="header-title33">REGA</span>
        </div>
        <div className="header-center44">
          <h1 className='h1'>Profile</h1>
        </div>
      </header>
      <div className='nav'>
        <nav className="sidebar">
          <button
            className="menu-icon" onClick={toggleNav}
            style={{ borderRadius: '50%', padding: '4px', borderColor: 'white' }}
          >⋮ ☰
          </button>
          {navOpen && (
            <ul className="nav-list1">
              <li className="nav-item">
                <Link to="/adminview" className="nav-link">Dashboard</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminemployee' className="nav-link"
                  style={{ background: '#a623ce', borderRadius: '20px' }}>Employees</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminpayroll' className="nav-link">Payroll</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminaxispayroll' className="nav-link">Axis Record</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminattendance'} className="nav-link">Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminaxisattendance'} className="nav-link">Axis Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminapplication'} className="nav-link">Application</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/admin'} className="nav-link">Logout</Link>
              </li>
            </ul>
          )}
          <div className='copy-nav'>
            <ul className="nav-list">
              <li className="nav-item">
                <Link to="/adminview" className="nav-link">Dashboard</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminemployee' className="nav-link"
                  style={{ background: '#a623ce', borderRadius: '20px' }}>Employees</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminpayroll' className="nav-link">Payroll</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminaxispayroll' className="nav-link">Axis Record</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminattendance'} className="nav-link">Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminaxisattendance'} className="nav-link">Axis Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminapplication'} className="nav-link">Application</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/admin'} className="nav-link">Logout</Link>
              </li>
            </ul>
          </div>
        </nav>
      </div>
      <div>
        {!navOpen && (
          <main style={{ backgroundColor: '#e1fdfb' }}>
            <div className="profile-image" style={{ alignItems: 'center', marginBottom: '20px' }}>
              <img
                src={image || icon}
                alt="Profile"
                className={`image-circle ${isZoomed ? 'zoomed' : ''}`}
                onClick={toggleZoom}
                style={{ maxWidth: '150px', maxHeight: '150px' }}
              />
              <input type="file" id="profileInput" onChange={handleImageChange} style={{ display: 'none' }} />
              <label htmlFor="profileInput" className="upload-button" style={{ marginTop: '10px' }}>Upload Picture</label>
            </div>
            <div className="profile-details" style={{ textAlign: 'center' }}>
              {filteredData.map(c => (
                <div key={c.username}>
                  <label className="profile-name" style={{ fontSize: '50px' }}>
                    {c.name}
                  </label><br />
                  <label className="profile-name" style={{ fontSize: '25px' }}>
                    ID:- {c.id}
                  </label>
                </div>
              ))}
            </div>
            <div>
              <table style={{
                width: '100%',
                borderCollapse: 'collapse',
                marginTop: '20px',
                fontSize: '16px',
                border: '1px solid #ddd',
              }}>
                <thead style={{ backgroundColor: '#685177' }}>
                  <tr>
                    <th style={{ padding: '12px', textAlign: 'center', border: '1px solid #000000' }}>Detail</th>
                    <th style={{ padding: '12px', textAlign: 'center', border: '1px solid #000000' }}>Upload</th>
                  </tr>
                </thead>
                <tbody style={{ backgroundColor: '#b69fc5' }}>
                  <tr>
                    <td style={{ padding: '12px', textAlign: 'center', border: '1px solid #000000' }}><strong>Aadhar Card photo</strong></td>
                    <td style={{ padding: '12px', textAlign: 'center', border: '1px solid #000000' }}>
                      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                        {aadharcard && (
                          <a href={aadharcard} target="_blank" rel="noopener noreferrer" style={{ display: 'flex', alignItems: 'center' }}>
                            <img src={aadharcard} alt="Aadhar Card" style={{ maxWidth: '100px', marginRight: '10px' }} />
                          </a>
                        )}
                        <input type="file" id="aadharInput" onChange={handleAadharCard} style={{ display: 'none' }} />
                        <label htmlFor="aadharInput" className="upload-button">Upload Aadhar Card</label>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td style={{ padding: '12px', textAlign: 'center', border: '1px solid #000000' }}><strong>Pan Card</strong></td>
                    <td style={{ padding: '12px', textAlign: 'center', border: '1px solid #000000' }}>
                      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                        {pancard && (
                          <a href={pancard} target="_blank" rel="noopener noreferrer" style={{ display: 'flex', alignItems: 'center' }}>
                            <img src={pancard} alt="Pan Card" style={{ maxWidth: '100px', marginRight: '10px' }} />
                          </a>
                        )}
                        <input type="file" id="panInput" onChange={handlePanCard} style={{ display: 'none' }} />
                        <label htmlFor="panInput" className="upload-button">Upload Pan Card</label>
                      </div>
                    </td>
                  </tr>
                  <tr>
                    <td style={{ padding: '12px', textAlign: 'center', border: '1px solid #000000' }}><strong>Qualification</strong></td>
                    <td style={{ padding: '12px', textAlign: 'center', border: '1px solid #000000' }}>
                      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                        {qualification && (
                          <a href={qualification} target="_blank" rel="noopener noreferrer" style={{ display: 'flex', alignItems: 'center' }}>
                            <img src={qualification} alt="Qualification" style={{ maxWidth: '100px', marginRight: '10px' }} />
                          </a>
                        )}
                        <input type="file" id="qualificationInput" onChange={handleQualification} style={{ display: 'none' }} />
                        <label htmlFor="qualificationInput" className="upload-button">Upload Qualification</label>
                      </div>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </main>
        )}
      </div>
    </div>
  );
}

export default demopro