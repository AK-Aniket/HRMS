import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import img1 from './image/logo.png';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import * as XLSX from 'xlsx';

const AdminPayroll = () => {
  const [payroll, setPayroll] = useState([]);
  const [filteredPayroll, setFilteredPayroll] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [editingIndex, setEditingIndex] = useState(null);
  const [editingRecord, setEditingRecord] = useState({});
  const [previousRecord, setPreviousRecord] = useState({});
  const navigate = useNavigate();
  const [selectedRows, setSelectedRows] = useState(new Set());
  const [showSelection, setShowSelection] = useState(false); // Initially hide checkboxes
  const [isDeleting, setIsDeleting] = useState(false); // State to track deletion in progress

  useEffect(() => {
    axios.get('http://192.168.1.150:3000/auth/adminpayroll')
      .then(result => {
        if (result.data.Status) {
          setPayroll(result.data.Result);
          setFilteredPayroll(result.data.Result);
        } else {
          alert(result.data.Error);
        }
      })
      .catch(err => console.log(err));
  }, []);

  const handleSearch = () => {
    const lowercasedSearchTerm = searchTerm.toLowerCase();
    const filtered = payroll.filter(record =>
      record['Salary_slip_no'].toLowerCase().includes(lowercasedSearchTerm) ||
      record['Employee_Name'].toLowerCase().includes(lowercasedSearchTerm)
    );
    setFilteredPayroll(filtered);
  };

  const handleInputChange = (e) => {
    setSearchTerm(e.target.value);
  };

  const handleExport = () => {
    const ws = XLSX.utils.json_to_sheet(filteredPayroll);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Payroll");
    XLSX.writeFile(wb, "Payroll.xlsx");
  };

  const startEditing = (index) => {
    setEditingIndex(index);
    const record = filteredPayroll[index];
    setEditingRecord(record);
    setPreviousRecord({
      Salary_slip_no: record['Salary_slip_no'],
      Employee_Name: record['Employee_Name']
    });
  };

  const handleDelete = () => {
    if (selectedRows.size === 0) {
      alert("No rows selected for deletion.");
      return;
    }

    setShowSelection(false); // Hide checkboxes
    setIsDeleting(true); // Set deleting status

    const slipnosToDelete = Array.from(selectedRows);

    axios.post('http://192.168.1.150:3000/auth/delete', { slipnos: slipnosToDelete })
      .then(result => {
        if (result.data.Status) {
          axios.get('http://192.168.1.150:3000/auth/adminpayroll')
            .then(result => {
              if (result.data.Status) {
                setPayroll(result.data.Result);
                setFilteredPayroll(result.data.Result);
                setSelectedRows(new Set());
                setShowSelection(false); // Hide checkboxes
                setIsDeleting(false); // Reset deleting status
              } else {
                alert(result.data.Error);
                setShowSelection(true); // Show checkboxes on error
                setIsDeleting(false); // Reset deleting status
              }
            })
            .catch(err => {
              console.log(err);
              setShowSelection(true); // Show checkboxes on error
              setIsDeleting(false); // Reset deleting status
            });
        } else {
          alert(result.data.Error);
          setShowSelection(true); // Show checkboxes on error
          setIsDeleting(false); // Reset deleting status
        }
      })
      .catch(err => {
        console.log(err);
        setShowSelection(true); // Show checkboxes on error
        setIsDeleting(false); // Reset deleting status
      });
  };


  const handleEditChange = (e, key) => {
    setEditingRecord({
      ...editingRecord,
      [key]: e.target.value
    });
  };

  const saveEdit = () => {
    const dataToSend = {
      date: editingRecord['Date'],
      salaryDetail: editingRecord['Salary_slip_no'],
      namee: editingRecord['Employee_Name'],
      salary: editingRecord['Salary'],
      staatus: editingRecord['Status'],
      slipno: previousRecord['Salary_slip_no'], // Use the previous slip number for identifying the record
      old_employee_name: previousRecord['Employee_Name'] // Use the previous employee name for identifying the record
    };

    axios.post('http://192.168.1.150:3000/auth/edit', dataToSend)
      .then(result => {
        if (result.data.Status) {
          // Fetch updated payroll data
          axios.get('http://192.168.1.150:3000/auth/adminpayroll')
            .then(result => {
              if (result.data.Status) {
                setPayroll(result.data.Result);
                setFilteredPayroll(result.data.Result);
                setEditingIndex(null);
                setEditingRecord({});
                setPreviousRecord({});
              } else {
                alert(result.data.Error);
              }
            })
            .catch(err => console.log(err));
        } else {
          alert(result.data.Error);
        }
      })
      .catch(err => console.log(err));
  };


  const tableStyles = {
    width: '100%',
    borderCollapse: 'collapse',
    marginTop: '20px',
    boxShadow: '0 0 10px rgba(0, 0, 0, 0.2)',
    border: '1px solid #ddd',
    borderRadius: '8px',
    overflow: 'hidden',
  };

  const thStyles = {
    border: '1px solid #ddd',
    padding: '12px 15px',
    textAlign: 'left',
    backgroundColor: '#6c5b7b',
    color: '#fff',
    fontWeight: 'bold',
    textTransform: 'uppercase',
  };

  const tdStyles = {
    border: '1px solid #ddd',
    padding: '12px 15px',
  };

  const rowStyles = {
    transition: 'background-color 0.3s ease, transform 0.3s ease',
  };

  const oddRowStyles = {
    backgroundColor: '#f9f9f9',
  };

  const evenRowStyles = {
    backgroundColor: '#ffffff',
  };

  const hoverRowStyles = {
    backgroundColor: '#f1f1f1',
    transform: 'scale(1.01)',
  };

  const [navOpen, setNavOpen] = useState(false); // State to handle sidebar visibility

  const toggleNav = () => {
    setNavOpen(!navOpen);
  };

  const handleNavClick = (path) => {
    navigate(path);
    setNavOpen(false); // Close the menu on navigation
  };

  return (
    <div>
      <header className="header11">
        <div><img src={img1} alt="Logo" /></div>
        <div className="header-left22">
          <span className="header-title33">REGA </span>
        </div>
        <div className="header-center44">
          <h1 className='h1'>Payroll</h1>
        </div>
      </header>
      <div className='nav'>
        <nav className="sidebar">
          <button
            className="menu-icon" onClick={toggleNav}
            style={{ borderRadius: '50%', padding: '4px', borderColor: 'white' }}
          >⋮ ☰
          </button>
          {navOpen && (
            <ul className="nav-list1">
              <li className="nav-item">
                <Link to="/adminview" className="nav-link">Dashboard</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminemployee' className="nav-link">Employees</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminpayroll' className="nav-link"
                  style={{ background: '#a623ce', borderRadius: '20px' }}>Payroll</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminaxispayroll' className="nav-link">Axis Record</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminattendance'} className="nav-link">Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminaxisattendance'} className="nav-link">Axis Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminapplication'} className="nav-link">Application</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/admin'} className="nav-link">Logout</Link>
              </li>
            </ul>
          )}
          <div className='copy-nav'>
            <ul className="nav-list">
              <li className="nav-item">
                <Link to="/adminview" className="nav-link">Dashboard</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminemployee' className="nav-link">Employees</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminpayroll' className="nav-link"
                  style={{ background: '#a623ce', borderRadius: '20px' }}>Payroll</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminaxispayroll' className="nav-link">Axis Record</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminattendance'} className="nav-link">Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminaxisattendance'} className="nav-link">Axis Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminapplication'} className="nav-link">Application</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/admin'} className="nav-link">Logout</Link>
              </li>
            </ul>
          </div>
        </nav>
      </div>
      <div>
        {!navOpen && (
          <main>
            <div className="payroll-table">
              <div style={{ marginBottom: '20px' }}>
                <button className="btn btn-primary" onClick={() => navigate('/add')} style={{ marginRight: '10px' }}>Add Record</button>
                <button
                  className="btn btn-info"
                  onClick={() => setShowSelection(true)} // Show selection checkboxes
                  style={{ marginRight: '10px' }}
                >
                  Delete
                </button>
                <button className="btn btn-success" onClick={handleExport}>Download Payroll</button>
              </div>
              <div style={{ marginBottom: '20px' }}>
                <input
                  type="text"
                  value={searchTerm}
                  onChange={handleInputChange}
                  placeholder="Search by Salary Slip No or Employee Name"
                  style={{
                    padding: '8px',
                    fontSize: '16px',
                    border: '1px solid #ddd',
                    borderRadius: '4px',
                    width: '250px',
                  }}
                />
                <button
                  className="btn btn-success ml-2"
                  onClick={handleSearch}
                  style={{ padding: '8px 16px', fontSize: '16px', margin: '10px' }}
                >
                  Search
                </button>
              </div>
              <div className='payroll1'>
                <table style={tableStyles}>
                  <thead>
                    <tr>
                      {showSelection && (
                        <th style={thStyles}>
                          <input
                            type="checkbox"
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedRows(new Set(filteredPayroll.map(record => record['Salary_slip_no'])));
                              } else {
                                setSelectedRows(new Set());
                              }
                            }}
                          />
                        </th>
                      )}
                      <th style={thStyles}>Date</th>
                      <th style={thStyles}>Salary Slip No</th>
                      <th style={thStyles}>Employee Name</th>
                      <th style={thStyles}>Salary</th>
                      <th style={thStyles}>Status</th>
                      <th style={thStyles}>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredPayroll.map((c, index) => (
                      <tr
                        key={index}
                        style={{
                          ...rowStyles,
                          ...(index % 2 === 0 ? evenRowStyles : oddRowStyles),
                        }}
                        onMouseEnter={e => e.currentTarget.style.backgroundColor = hoverRowStyles.backgroundColor}
                        onMouseLeave={e => e.currentTarget.style.backgroundColor = index % 2 === 0 ? evenRowStyles.backgroundColor : oddRowStyles.backgroundColor}
                      >
                        {showSelection && (
                          <td style={tdStyles}>
                            <input
                              type="checkbox"
                              checked={selectedRows.has(c['Salary_slip_no'])}
                              onChange={() => {
                                const newSelectedRows = new Set(selectedRows);
                                if (newSelectedRows.has(c['Salary_slip_no'])) {
                                  newSelectedRows.delete(c['Salary_slip_no']);
                                } else {
                                  newSelectedRows.add(c['Salary_slip_no']);
                                }
                                setSelectedRows(newSelectedRows);
                              }}
                            />
                          </td>
                        )}
                        <td style={tdStyles}>
                          {editingIndex === index ? (
                            <input
                              type="text"
                              value={editingRecord['Date'] || ''}
                              onChange={(e) => handleEditChange(e, 'Date')}
                            />
                          ) : (
                            c['Date']
                          )}
                        </td>
                        <td style={tdStyles}>
                          {editingIndex === index ? (
                            <input
                              type="text"
                              value={editingRecord['Salary_slip_no'] || ''}
                              onChange={(e) => handleEditChange(e, 'Salary_slip_no')}
                            />
                          ) : (
                            c['Salary_slip_no']
                          )}
                        </td>
                        <td style={tdStyles}>
                          {editingIndex === index ? (
                            <input
                              type="text"
                              value={editingRecord['Employee_Name'] || ''}
                              onChange={(e) => handleEditChange(e, 'Employee_Name')}
                            />
                          ) : (
                            c['Employee_Name']
                          )}
                        </td>
                        <td style={tdStyles}>
                          {editingIndex === index ? (
                            <input
                              type="text"
                              value={editingRecord['Salary'] || ''}
                              onChange={(e) => handleEditChange(e, 'Salary')}
                            />
                          ) : (
                            c['Salary']
                          )}
                        </td>
                        <td style={tdStyles}>
                          {editingIndex === index ? (
                            <input
                              type="text"
                              value={editingRecord['Status'] || ''}
                              onChange={(e) => handleEditChange(e, 'Status')}
                            />
                          ) : (
                            c['Status']
                          )}
                        </td>
                        <td style={tdStyles}>
                          {editingIndex === index ? (
                            <button
                              className="btn btn-success"
                              onClick={saveEdit}
                            >
                              Save
                            </button>
                          ) : (
                            <button
                              className="btn btn-info"
                              onClick={() => startEditing(index)}
                            >
                              Edit
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {showSelection && (
                <button className="btn btn-danger" onClick={handleDelete} disabled={isDeleting}>
                  {isDeleting ? 'Deleting...' : 'Confirm Delete'}
                </button>
              )}
            </div>
          </main>
        )}
      </div>
    </div>
  );
};

export default AdminPayroll;
