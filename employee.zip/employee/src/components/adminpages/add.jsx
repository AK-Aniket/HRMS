import React, { useState, useEffect } from 'react';
import '../style/attendance.css'
import { Link } from 'react-router-dom';
import img1 from './image/logo.png';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const add = () => {

    const [value, setValue] = useState({
        date: '',
        salaryDetail: '',
        namee: '',
        salary: '',
        staatus: ''

    })
    const Navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault()
        axios.post('http://192.168.1.150:3000/auth/add', value)
            .then(result => {
                if (result.data.Status) {
                    Navigate('/adminpayroll')
                }
                else {
                    alert(result.data.Error)
                }
            })
            .catch(err => console.log(err))
    }

    const navigate = useNavigate()
    const [navOpen, setNavOpen] = useState(false); // State to handle sidebar visibility

    const toggleNav = () => {
        setNavOpen(!navOpen);
    };

    const handleNavClick = (path) => {
        navigate(path);
        setNavOpen(false); // Close the menu on navigation
    };

    const styles = {
        mainContent: {
            flex: '1',
            padding: '20px',
        },
        container: {
            maxWidth: '600px',
            margin: 'auto',
            padding: '20px',
            backgroundColor: '#fff',
            border: '1px solid #ddd',
            borderRadius: '8px',
            boxShadow: '0 0 20px rgba(0, 0, 0, 0.1)',
        },
        formGroup: {
            marginBottom: '15px',
        },
        label: {
            display: 'block',
            marginBottom: '5px',
        },
        formControl: {
            width: '100%',
            padding: '8px',
            fontSize: '14px',
            border: '3px solid #ccc',
            borderRadius: '4px',
        },
        btnPrimary: {
            backgroundColor: '#007bff',
            color: '#fff',
            border: 'none',
            padding: '10px 20px',
            cursor: 'pointer',
            borderRadius: '4px',
        },
        btnPrimaryHover: {
            backgroundColor: '#0056b3',
        },
    };

    return (
        <div>
            <header className="header11">
                <div><img src={img1} alt="Logo" /></div>
                <div className="header-left22">
                    <span className="header-title33">REGA </span>
                </div>
                <div className="header-center44">
                    <h1 className='h1'>ADD Record</h1>
                </div>
            </header>
            <div className='nav'>
                <nav className="sidebar">
                    <button
                        className="menu-icon" onClick={toggleNav}
                        style={{ borderRadius: '50%', padding: '4px', borderColor: 'white' }}
                    >⋮ ☰
                    </button>
                    {navOpen && (
                        <ul className="nav-list1">
                            <li className="nav-item">
                                <Link to="/adminview" className="nav-link">Dashboard</Link>
                            </li>
                            <li className="nav-item">
                                <Link to='/adminemployee' className="nav-link">Employees</Link>
                            </li>
                            <li className="nav-item">
                                <Link to='/adminpayroll' className="nav-link"
                                    style={{ background: '#a623ce', borderRadius: '20px 20px 20px 20px' }}>Payroll</Link>
                            </li>
                            <li className="nav-item">
                                <Link to='/adminaxispayroll' className="nav-link">Axis Record</Link>
                            </li>
                            <li className='nav-item'>
                                <Link to={'/adminattendance'} className="nav-link">Attendance</Link>
                            </li>
                            <li className='nav-item'>
                                <Link to={'/adminaxisattendance'} className="nav-link">Axis Attendance</Link>
                            </li>
                            <li className='nav-item'>
                                <Link to={'/adminapplication'} className="nav-link">Application</Link>
                            </li>
                            <li className='nav-item'>
                                <Link to={'/admin'} className="nav-link">Logout</Link>
                            </li>
                        </ul>
                    )}
                    <div className='copy-nav'>
                        <ul className="nav-list">
                            <li className="nav-item">
                                <Link to="/adminview" className="nav-link">Dashboard</Link>
                            </li>
                            <li className="nav-item">
                                <Link to='/adminemployee' className="nav-link">Employees</Link>
                            </li>
                            <li className="nav-item">
                                <Link to='/adminpayroll' className="nav-link"
                                    style={{ background: '#a623ce', borderRadius: '20px 20px 20px 20px' }}>Payroll</Link>
                            </li>
                            <li className="nav-item">
                                <Link to='/adminaxispayroll' className="nav-link">Axis Record</Link>
                            </li>
                            <li className='nav-item'>
                                <Link to={'/adminattendance'} className="nav-link">Attendance</Link>
                            </li>
                            <li className='nav-item'>
                                <Link to={'/adminaxisattendance'} className="nav-link">Axis Attendance</Link>
                            </li>
                            <li className='nav-item'>
                                <Link to={'/adminapplication'} className="nav-link">Application</Link>
                            </li>
                            <li className='nav-item'>
                                <Link to={'/admin'} className="nav-link">Logout</Link>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
            <div>
                {!navOpen && (
                    <main style={styles.mainContent}>
                        <div className="container" style={styles.container}>
                            <form onSubmit={handleSubmit}>
                                <h1 style={styles.h1}>Enter All Details</h1>
                                <div className="form-group" style={styles.formGroup}>
                                    <label style={styles.label}>Enter Date :</label>
                                    <input type="date" id="date" name="date"
                                        className="form-control" style={styles.formControl}
                                        onChange={(e) => setValue({ ...value, date: e.target.value })} required />
                                </div>
                                <div className="form-group" style={styles.formGroup}>
                                    <label style={styles.label}>Enter Salary slip No:</label>
                                    <input type="text" id="salarydetail" name="salarydetail"
                                        className="form-control" style={styles.formControl}
                                        onChange={(e) => setValue({ ...value, salaryDetail: e.target.value })} required />
                                </div>
                                <div className="form-group" style={styles.formGroup}>
                                    <label htmlFor="player3" style={styles.label}>Enter Name:</label>
                                    <input type="text" id="name" name="namee"
                                        className="form-control" style={styles.formControl}
                                        onChange={(e) => setValue({ ...value, namee: e.target.value })} required />
                                </div>
                                <div className="form-group" style={styles.formGroup}>
                                    <label htmlFor="player4" style={styles.label}>Salary:</label>
                                    <input type="Number" id="salary" name="salary"
                                        className="form-control" style={styles.formControl}
                                        onChange={(e) => setValue({ ...value, salary: e.target.value })} required />
                                </div>
                                <div className="form-group" style={styles.formGroup}>
                                    <label htmlFor="player5" style={styles.label}>Status:</label>
                                    <input type="text" id="staatus" name="staatus"
                                        className="form-control" style={styles.formControl}
                                        onChange={(e) => setValue({ ...value, staatus: e.target.value })} required />
                                </div>
                                <button type="submit" className="btn btn-primary"
                                    style={styles.btnPrimary}>Submit</button>
                            </form>
                        </div>
                    </main>
                )}
            </div>
        </div>
    );
}

export default add;
