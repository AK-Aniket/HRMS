import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import img1 from './image/logo.png';
import axios from 'axios';

const Admindashboard = () => {
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [totalEmployees, setTotalEmployees] = useState(0);
  const [activeEmployees, setActiveEmployees] = useState(0);
  const [totalApplication, setTotalApplication] = useState(0);
  const [profile, setProfile] = useState([]);
  const filteredProfile = profile; // Assuming you want to use the full profile

  const activeCount = filteredProfile.filter(c => c.status === 'Active').length;
  const inActiveCount = filteredProfile.filter(c => c.status === 'Inactive').length;
  const breakCount = filteredProfile.filter(c => ['Tea Break', 'Lunch Break', 'Emergency Break'].includes(c.status)).length;

  const fetchData = () => {
    const today = new Date().toISOString().split('T')[0];
    setDate(today);

    // Fetch active employees for the current date
    axios.post('http://192.168.1.150:3000/auth/activeemployee', { date: today })
      .then(result => {
        if (result.data.Status) {
          setActiveEmployees(result.data.Count);
        } else {
          alert(result.data.Error);
        }
      })
      .catch(err => console.log('Error fetching active employees:', err));

    // Fetch today's applications
    axios.post('http://192.168.1.150:3000/auth/todaysapplication', { date: today })
      .then(result => {
        if (result.data.Status) {
          setTotalApplication(result.data.Count);
        } else {
          alert(result.data.Error);
        }
      })
      .catch(err => console.log("Error fetching today's applications:", err));

    // Fetch total number of employees
    axios.post('http://192.168.1.150:3000/auth/totalemployee')
      .then(result => {
        if (result.data.Status) {
          setTotalEmployees(result.data.Count);
        } else {
          alert(result.data.Error);
        }
      })
      .catch(err => console.log('Error fetching total employees:', err));

    // Fetch profile data
    axios.get('http://192.168.1.150:3000/auth/profile')
      .then(result => {
        if (result.data.Status) {
          setProfile(result.data.Result);
        } else {
          alert(result.data.Error);
        }
      })
      .catch(err => console.log(err));
  };

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 2000);
    return () => clearInterval(interval); // Cleanup interval on component unmount
  }, []);

  const tableStyle = {
    width: '100%',
    borderCollapse: 'collapse',
    marginTop: '20px',
    boxShadow: '0 0 20px rgba(0, 0, 0, 0.1)',
  };

  const thStyle = {
    backgroundColor: '#c66fe0',
    borderBottom: '2px solid #dee2e6',
    padding: '12px 15px',
    textAlign: 'left',
  };

  const tdStyle = {
    padding: '12px 15px',
    textAlign: 'left',
  };

  const inactiveRowStyle = {
    backgroundColor: '#ffcccc', // Light red background for inactive rows
  };

  const activeStyle = {
    backgroundColor: '#daf7d3', // Light green background for active rows
  };

  const breakStyle = {
    backgroundColor: 'yellow', // Light yellow background for break rows
  };

  const navigate = useNavigate(); // Hook for navigation
  const [navOpen, setNavOpen] = useState(false); // State to handle sidebar visibility

  const toggleNav = () => {
    setNavOpen(!navOpen);
  };

  const handleNavClick = (path) => {
    navigate(path);
    setNavOpen(false); // Close the menu on navigation
  };

  return (
    <div>
      <header className="header11">
        <div><img src={img1} alt="Logo" /></div>
        <div className="header-left22">
          <span className="header-title33">REGA </span>
        </div>
        <div className="header-center44">
          <h1 className='h1'>Admin View</h1>
        </div>
      </header>
      <div className='nav'>
        <nav className="sidebar">
          <button
            className="menu-icon" onClick={toggleNav}
            style={{ borderRadius: '50%', padding: '4px', borderColor: 'white' }}
          >⋮ ☰
          </button>
          {navOpen && (
            <ul className="nav-list1">
              <li className="nav-item">
                <Link to="#" className="nav-link"
                  style={{ background: '#a623ce', borderRadius: '20px 20px 20px 20px' }}>Dashboard</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminemployee' className="nav-link">Employees</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminpayroll' className="nav-link">Payroll</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminaxispayroll' className="nav-link">Axis Record</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminattendance'} className="nav-link">Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminaxisattendance'} className="nav-link">Axis Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminapplication'} className="nav-link">Application</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/admin'} className="nav-link">Logout</Link>
              </li>
            </ul>
          )}
          <div className='copy-nav'>
            <ul className="nav-list">
              <li className="nav-item">
                <Link to="#" className="nav-link"
                  style={{ background: '#a623ce', borderRadius: '20px 20px 20px 20px' }}>Dashboard</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminemployee' className="nav-link">Employees</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminpayroll' className="nav-link">Payroll</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminaxispayroll' className="nav-link">Axis Record</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminattendance'} className="nav-link">Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminaxisattendance'} className="nav-link">Axis Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminapplication'} className="nav-link">Application</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/admin'} className="nav-link">Logout</Link>
              </li>
            </ul>
          </div>
        </nav>
      </div>
      <div>
        {!navOpen && (
          <main style={{
            padding: '25px',
            display: 'grid',
            gridTemplateColumns: 'repeat(2, 2fr)',
            gridTemplateRows: 'repeat(2, auto)',
            gap: '20px',
            background: '#f8f8e6',
            borderRadius: '10px',
            boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
            color: '#333',
            fontFamily: '"Roboto", sans-serif',
          }}>
            <div style={{
              background: '#ccf7f1',
              padding: '20px',
              borderRadius: '10px',
              boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
              textAlign: 'center',
              gridColumn: 'span 1', // Span only 1 column
            }}>
              <h1 style={{
                fontSize: '24px',
                color: '#2c3e50',
                marginBottom: '10px',
                fontWeight: '600'
              }}>Total No of Employees</h1>
              <p style={{
                fontSize: '32px',
                color: '#3498db',
                fontWeight: '700'
              }}>{totalEmployees}</p>
            </div>
            <div style={{
              background: '#d4ebc5',
              padding: '20px',
              borderRadius: '10px',
              boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
              textAlign: 'center',
              gridColumn: 'span 1', // Span only 1 column
            }}>
              <h2 style={{
                fontSize: '24px',
                color: '#2c3e50',
                marginBottom: '10px',
                fontWeight: '600'
              }}>Total No of Employee Present</h2>
              <p style={{
                fontSize: '28px',
                color: '#27ae60',
                fontWeight: '700'
              }}>{activeCount+breakCount}</p>
            </div>
            <div style={{
              background: '#ecd9e2',
              padding: '20px',
              borderRadius: '10px',
              boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
              textAlign: 'center',
              gridColumn: 'span 1', // Span only 1 column
            }}>
              <h2 style={{
                fontSize: '24px',
                color: '#2c3e50',
                marginBottom: '10px',
                fontWeight: '600'
              }}>Total No of Employee Absent</h2>
              <p style={{
                fontSize: '28px',
                color: '#c0392b',
                fontWeight: '700'
              }}>{totalEmployees - (activeCount+breakCount)}</p>
            </div>
            <div style={{
              background: '#d3cff7',
              padding: '20px',
              borderRadius: '10px',
              boxShadow: '0 4px 8px rgba(0,0,0,0.1)',
              textAlign: 'center',
              gridColumn: 'span 1', // Span only 1 column
            }}>
              <h2 style={{
                fontSize: '24px',
                color: '#2c3e50',
                marginBottom: '10px',
                fontWeight: '600'
              }}>Today's Applications</h2>
              <p style={{
                fontSize: '28px',
                color: '#2980b9',
                fontWeight: '700'
              }}>{totalApplication}</p>
            </div>
            <div style={{
              borderRadius: '10px',
              textAlign: 'center',
              gridColumn: 'span 2',
            }}>
              <div className='table1'>
                <table style={tableStyle}>
                  <thead>
                    <tr>
                      <th style={thStyle}>Sr.no</th>
                      <th style={thStyle}>Employee Name</th>
                      <th style={thStyle}>Designation</th>
                      <th style={thStyle}>Current Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredProfile.map((c, index) => {
                      let rowStyle = null;

                      if (c.status === "Inactive") {
                        rowStyle = inactiveRowStyle;
                      } else if (c.status === "Active") {
                        rowStyle = activeStyle;
                      } else if (['Tea Break', 'Lunch Break', 'Emergency Break'].includes(c.status)) {
                        rowStyle = breakStyle;
                      }

                      return (
                        <tr key={c.id} style={rowStyle}>
                          <td style={tdStyle}><strong>{index + 1}</strong></td>
                          <td style={tdStyle}><strong>{c.name}</strong></td>
                          <td style={tdStyle}><strong>{c.department}</strong></td>
                          <td style={tdStyle}><strong>{c.status}</strong></td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </main>
        )}
      </div>
    </div>
  );
};

export default Admindashboard;
