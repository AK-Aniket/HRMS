import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import img1 from './image/logo.png';

const admincompose = () => {
  const navigate = useNavigate();
  const [valuess, setValuess] = useState({
    name: 'Rega Enterprises',
    from: 'Rega@regaenterprises.com',
    to: '',
    subject: '',
    message: '',
    date: '', // Automatic date field
    time: '', // Time field
  });
  const [files, setFiles] = useState([]);

  // Set the current date and time when the component mounts
  useEffect(() => {
    const currentDate = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
    const currentTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); // HH:MM format
    setValuess(prevState => ({ ...prevState, date: currentDate, time: currentTime }));
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setValuess(prevState => ({ ...prevState, [name]: value }));
  };

  const handleFileChange = (e) => {
    setFiles(e.target.files);
  };

  const handleSubmit1 = (e) => {
    e.preventDefault();
    const formData = new FormData();
    formData.append('name', valuess.name);
    formData.append('from', valuess.from);
    formData.append('to', valuess.to);
    formData.append('subject', valuess.subject);
    formData.append('message', valuess.message);
    formData.append('date', valuess.date);
    formData.append('time', valuess.time);
    for (let i = 0; i < files.length; i++) {
      formData.append('files', files[i]);
    }

    axios.post('http://192.168.1.150:3000/auth/send', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    })
      .then(result => {
        if (result.data.Status) {
          navigate('/adminapplication');
        } else {
          alert(result.data.Error);
        }
      })
      .catch(err => console.error(err));
  };

  const [navOpen, setNavOpen] = useState(false); // State to handle sidebar visibility

  const toggleNav = () => {
    setNavOpen(!navOpen);
  };

  const handleNavClick = (path) => {
    navigate(path);
    setNavOpen(false); // Close the menu on navigation
  };

  return (
    <div>
      <header className="header11">
        <div><img src={img1} alt="Logo" /></div>
        <div className="header-left22">
          <span className="header-title33">REGA </span>
        </div>
        <div className="header-center44">
          <h1 className='h1'>Compose</h1>
        </div>
      </header>

      <div className='nav'>
        <nav className="sidebar">
          <button
            className="menu-icon" onClick={toggleNav}
            style={{ borderRadius: '50%', padding: '4px', borderColor: 'white' }}
          >⋮ ☰
          </button>
          {navOpen && (
            <ul className="nav-list1">
              <li className="nav-item">
                <Link to="/adminview" className="nav-link">Dashboard</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminemployee' className="nav-link">Employees</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminpayroll' className="nav-link">Payroll</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminaxispayroll' className="nav-link">Axis Record</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminattendance'} className="nav-link">Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminaxisattendance'} className="nav-link">Axis Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminapplication'} className="nav-link"
                  style={{ background: '#a623ce', borderRadius: '20px' }}>Application</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/admin'} className="nav-link">Logout</Link>
              </li>
            </ul>
          )}
          <div className='copy-nav'>
            <ul className="nav-list">
              <li className="nav-item">
                <Link to="/adminview" className="nav-link">Dashboard</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminemployee' className="nav-link">Employees</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminpayroll' className="nav-link">Payroll</Link>
              </li>
              <li className="nav-item">
                <Link to='/adminaxispayroll' className="nav-link">Axis Record</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminattendance'} className="nav-link">Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminaxisattendance'} className="nav-link">Axis Attendance</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/adminapplication'} className="nav-link"
                  style={{ background: '#a623ce', borderRadius: '20px' }}>Application</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/admin'} className="nav-link">Logout</Link>
              </li>
            </ul>
          </div>
        </nav>
      </div>
      <form onSubmit={handleSubmit1}>
        <div>
          {!navOpen && (
            <main className="main-content">
              <div className="gmail-like-container">
                <div className="gmail-menu">
                  <ul className="gmail-menu-list">
                    <li className="gmail-menu-item"><Link style={{ color: 'black' }} to={'/adminapplication'}>Inbox</Link></li>
                    <li className="gmail-menu-item"><Link style={{ color: 'black' }} to={'/adminsend'}>Sent</Link></li>
                    <li className="gmail-menu-item activ"><Link to={'/admincompose'}>Compose</Link></li>
                  </ul>
                </div>
                <div className="gmail-content">
                  <h2>Send Application</h2>
                  <label htmlFor="from">From:-</label>
                  <input
                    type='email'
                    id='from'
                    name='from'
                    value={valuess.from}
                    onChange={handleChange}
                    required
                  />
                  <br />
                  <label htmlFor="to">To:-</label>
                  <input
                    type='email'
                    id='to'
                    name='to'
                    value={valuess.to}
                    onChange={handleChange}
                    required
                  />
                  <br />
                  <label htmlFor="subject">Subject:-</label>
                  <input
                    type='text'
                    id='subject'
                    name='subject'
                    value={valuess.subject}
                    onChange={handleChange}
                    required
                  />
                  <br />
                  <label htmlFor="message">Message:-</label>
                  <textarea
                    id='message'
                    name='message'
                    value={valuess.message}
                    onChange={handleChange}
                    required
                  />
                  <br />
                  <label htmlFor="files">Attach Files:-</label>
                  <input
                    type="file"
                    id="files"
                    name="files"
                    multiple
                    onChange={handleFileChange}
                  />
                  <br />
                  <button type="submit">Send</button>
                  <div id="error" style={{ color: 'red', marginTop: '10px' }}></div>
                </div>
              </div>
            </main>
          )}
        </div>
      </form>
      <style>
        {`

.gmail-content input,
.gmail-content textarea {
  width: calc(100% - 24px); /* Account for padding */
  padding: 12px;
  margin-top: 6px;
  margin-bottom: 16px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 16px;
  box-sizing: border-box; /* Ensure padding is included in width */
}

.gmail-content textarea {
  height: 180px;
  resize: vertical;
}

.gmail-content button {
  background-color: #007bff;
  color: #fff;
  border: none;
  padding: 12px 24px;
  border-radius: 6px;
  cursor: pointer;
  font-size: 16px;
  transition: background-color 0.3s ease;
}

.gmail-content button:hover {
  background-color: #0056b3;
}
        `}
      </style>
    </div>
  );
}

export default admincompose