import React, { useState, useEffect } from 'react';
import '../../style/attendance.css';
import { Link, useNavigate } from 'react-router-dom';
import { formatISO, startOfDay, isMonday, isSunday } from 'date-fns';
import img1 from '../image/logo.png';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import axios from 'axios';

const attendance = () => {
    const [date, setDate] = useState(new Date());
    const [searchDate, setSearchDate] = useState('');
    const [highlightedDates, setHighlightedDates] = useState([]);
    const [isPunchedIn, setIsPunchedIn] = useState(false);
    const [isPunchedOut, setIsPunchedOut] = useState(false);
    const [punchInTime, setPunchInTime] = useState('');
    const [punchOutTime, setPunchOutTime] = useState('');
    const [employeeNameToFilter, setEmployeeNameToFilter] = useState('');
    const [absentDates, setAbsentDates] = useState(new Set());
    const [times, setTimes] = useState({ punch_in: '', punch_out: '' });
    const [refresh, setRefresh] = useState(0); // State to trigger refresh

    useEffect(() => {
        const fetchAttendanceData = async () => {
            try {
                const result = await axios.get('http://192.168.1.150:3000/auth/axisgetAttendance', {
                    params: { name: employeeNameToFilter }
                });

                if (result.data.Status) {
                    const dates = result.data.Result.map(record => new Date(record.date));
                    setHighlightedDates(dates);
                } else {
                    alert(result.data.Error);
                }
            } catch (err) {
                console.error(err);
            }
        };

        const fetchPunchTimes = async () => {
            const selectedDate = startOfDay(date);
            const formattedDate = formatISO(selectedDate, { representation: 'date' });

            try {
                const result = await axios.post('http://192.168.1.150:3000/auth/axisgetPunchTimes', {
                    date: formattedDate,
                    name: employeeNameToFilter
                });

                if (result.data.Status) {
                    const { punch_in, punch_out } = result.data.Result;
                    setTimes({ punch_in, punch_out });
                    setPunchInTime(punch_in || '');
                    setPunchOutTime(punch_out || '');
                    setIsPunchedIn(!!punch_in);
                    setIsPunchedOut(!!punch_out);

                } else {
                    setPunchInTime('');
                    setPunchOutTime('');
                    setIsPunchedIn(false);
                    setIsPunchedOut(false);
                }
            } catch (err) {
                console.error(err);
            }
        };

        fetchAttendanceData();
        fetchPunchTimes();

        const intervalId = setInterval(() => {
            fetchAttendanceData();
            fetchPunchTimes();
            setRefresh(prev => prev + 1); // Trigger refresh
        }, 2000);

        return () => clearInterval(intervalId);
    }, [date, employeeNameToFilter]);

    const handleSearchDateChange = event => {
        setSearchDate(event.target.value);
    };

    const handlePunchIn = () => {
        const currentTime = new Date();
        if (date.toDateString() === currentTime.toDateString() && !absentDates.has(currentTime.toDateString())) {
            const punchInData = {
                Name: employeeNameToFilter,
                date: currentTime.toISOString().split('T')[0],
                Punch_In: formatTime(currentTime)
            };

            axios.post('http://192.168.1.150:3000/auth/axispunchin', punchInData)
                .then(() => {
                    setPunchInTime(formatTime(currentTime));
                })
                .catch(error => {
                    console.error('Error punching in:', error);
                    alert('Failed to punch in.');
                });
        } else {
            alert('Can not tag, this break is already used');
        }
    };

    const handlePunchOut = async () => {
        console.log('Attempting to punch out...'); // Debug log

        const currentTime = new Date();
        if (date.toDateString() === currentTime.toDateString() && isPunchedIn && !absentDates.has(currentTime.toDateString())) {
            const duration = calculateDuration(punchInTime, formatTime(currentTime));
            const formattedDate = formatISO(startOfDay(currentTime), { representation: 'date' });

            const punchOutData = {
                date: formattedDate,
                Punch_Out: formatTime(currentTime),
                statu: duration.duration,
                Name: employeeNameToFilter,
            };

            console.log('Punch Out Data:', punchOutData); // Debug log

            try {
                const result = await axios.post('http://192.168.1.150:3000/auth/axispunchout', punchOutData);
                console.log('Punch Out Response:', result.data); // Debug log

                if (result.data.Status) {
                    setPunchOutTime(formatTime(currentTime));
                    setIsPunchedOut(true);
                    console.log('Punch out successful');
                } else {
                    console.error('Punch out failed:', result.data.Error); // Error logging
                    alert('Failed to punch out.');
                }
            } catch (error) {
                console.error('Error punching out:', error);
                alert('Failed to punch out.');
            }
        } else {
            alert('Cannot punch out. Ensure you have punched in and it is not marked as absent.');
        }
    };

    const calculateDuration = (startTime, endTime) => {
        const [startHours, startMinutes, startSeconds] = startTime.split(':').map(Number);
        const [endHours, endMinutes, endSeconds] = endTime.split(':').map(Number);

        const startDate = new Date(0, 0, 0, startHours, startMinutes, startSeconds);
        const endDate = new Date(0, 0, 0, endHours, endMinutes, endSeconds);

        const diff = endDate - startDate;
        const totalSeconds = Math.floor(diff / 1000);
        const hours = Math.floor(totalSeconds / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const seconds = totalSeconds % 60;

        return {
            duration: `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`,
            totalMinutes: Math.floor(totalSeconds / 60),
            totalSeconds
        };
    };

    const username = localStorage.getItem('username');

    const fetchProfileData = async () => {
        try {
            const result = await axios.get('http://192.168.1.150:3000/auth/profile');
            if (result.data.Status) {
                const filteredProfile = result.data.Result.find(c => c.username === username);
                if (filteredProfile) {
                    setEmployeeNameToFilter(filteredProfile.name);
                }
            } else {
                alert(result.data.Error);
            }
        } catch (err) {
            console.log(err);
        }
    };

    fetchProfileData();

    const formatTime = time => {
        const hours = String(time.getHours()).padStart(2, '0');
        const minutes = String(time.getMinutes()).padStart(2, '0');
        const seconds = String(time.getSeconds()).padStart(2, '0');
        return `${hours}:${minutes}:${seconds}`;
    };

    const handleSearchDateSubmit = event => {
        event.preventDefault();
        const parsedDate = new Date(searchDate);
        if (!isNaN(parsedDate.getTime())) {
            setDate(parsedDate);
            setSearchDate('');
        }
    };

    const handleClear = () => {
        const selectedDate = startOfDay(date);
        const formattedDate = formatISO(selectedDate, { representation: 'date' });

        console.log('Fetching punch times for date:', formattedDate); // Debug log

        try {
            axios.post('http://192.168.1.150:3000/auth/axisdeleteattendance', {
                date: formattedDate,
                Name: employeeNameToFilter
            }).then(result => {
                if (result.data.Status) {
                    setPunchInTime('');
                    setPunchOutTime('');
                    setIsPunchedIn(false);
                    setIsPunchedOut(false);
                }
            });
        } catch (err) {
            console.log(err);
        }
    };

    const tileClassName = ({ date }) => {
        const isHighlighted = highlightedDates.some(d => isSameDay(d, date));
        const today = new Date();
        const isPastDate = date < startOfDay(today);

        if (isSunday(date)) {
            return 'highlighted-monday'; // Highlight Mondays
        }

        if (isPastDate && !isHighlighted) {
            return 'absent-date'; // Highlight past dates not in data
        }

        return isHighlighted ? 'highlighted-date' : null;
    };

    const tileContent = ({ date }) => {
        const today = new Date();
        const isPastDate = date < startOfDay(today);
        const isHoliday = isSunday(date);

        if (isHoliday) {
            return <div className="holiday-label">WeekOff</div>;
        }

        if (isPastDate && !highlightedDates.some(d => isSameDay(d, date))) {
            return <div className="absent-label">Absent</div>;
        }

        return null;
    };

    const isSameDay = (date1, date2) => (
        date1.getFullYear() === date2.getFullYear() &&
        date1.getMonth() === date2.getMonth() &&
        date1.getDate() === date2.getDate()
    );

    const navigate = useNavigate(); // Hook for navigation
    const [navOpen, setNavOpen] = useState(false); // State to handle sidebar visibility

    const toggleNav = () => {
        setNavOpen(!navOpen);
    };

    const handleNavClick = (path) => {
        navigate(path);
        setNavOpen(false); // Close the menu on navigation
    };

    return (
        <div>
            <header className="header11">
                <img src={img1} alt="Logo" />
                <div className="header-left22">
                    <span className="header-title33">REGA</span>
                </div>
                <div className="header-center44">
                    <h1 className="h1">Attendance</h1>
                </div>
            </header>
            <div className='nav'>
                <nav className="sidebar">
                    <button
                        className="menu-icon" onClick={toggleNav}
                        style={{ borderRadius: '50%', padding: '4px', borderColor: 'white' }}
                    >⋮ ☰
                    </button>
                    {navOpen && (
                        <ul className="nav-list1">
                            <li className="nav-item">
                                <Link to='/demoprofile' className="nav-link" >Profile</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/demopayroll" className="nav-link">Entry Record</Link>
                            </li>
                            <li className="nav-item">
                                <Link to='/demoattendance' className="nav-link"
                                    style={{ background: '#a623ce', borderRadius: '20px' }}>Attendance</Link>
                            </li>
                            <li className='nav-item'>
                                <Link to={'/'} className="nav-link">Logout</Link>
                            </li>
                        </ul>
                    )}
                    <div className='copy-nav'>
                        <ul className="nav-list">
                            <li className="nav-item">
                                <Link to='/demoprofile' className="nav-link" >Profile</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/demopayroll" className="nav-link">Entry Record</Link>
                            </li>
                            <li className="nav-item">
                                <Link to='/demoattendance' className="nav-link"
                                    style={{ background: '#a623ce', borderRadius: '20px' }}>Attendance</Link>
                            </li>
                            <li className='nav-item'>
                                <Link to={'/'} className="nav-link">Logout</Link>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
            <div>
                {!navOpen && (
                    <main>
                        <div className="search-bar">
                            <form onSubmit={handleSearchDateSubmit}>
                                <input type="date" value={searchDate} onChange={handleSearchDateChange} />
                                <button type="submit">Search</button>
                            </form>
                        </div>
                        <div className="calendar-container">
                            <Calendar
                                onChange={setDate}
                                value={date}
                                tileClassName={tileClassName}
                                tileContent={tileContent}
                            />
                        </div>
                        <div className="buttons-container">
                            <button
                                className="punch-button"
                                style={{ marginTop: '45px', marginBottom: '45px', borderRadius: '8px' }}
                                onClick={handlePunchIn}
                                disabled={isPunchedIn || isPunchedOut}
                            >
                                Punch In
                            </button>
                            <button
                                className="punch-button"
                                style={{ marginTop: '45px', marginBottom: '45px', borderRadius: '8px' }}
                                onClick={handlePunchOut}
                                disabled={!isPunchedIn || isPunchedOut}
                            >
                                Punch Out
                            </button>
                        </div>
                        <div className="time-display" style={{ marginTop: '15px' }}>
                            {punchInTime && <div>Punch In: {punchInTime}</div>}
                            {punchOutTime && <div>Punch Out : {punchOutTime}</div>}
                        </div>
                    </main>
                )}
            </div>
        </div>
    );
};

export default attendance;
