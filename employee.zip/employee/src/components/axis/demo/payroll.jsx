import { Link, useNavigate } from 'react-router-dom';
import img1 from '../image/logo.png';
import { useState, useEffect } from 'react';
import axios from 'axios';

const payroll = () => {
    const [payroll, setPayroll] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [filteredPayroll, setFilteredPayroll] = useState([]);
    const [error, setError] = useState('');
    const [employeeNameToFilter, setEmployeeNameToFilter] = useState('');

    const username = localStorage.getItem('username');

    useEffect(() => {
        axios.get('http://192.168.1.150:3000/auth/axispayroll')
            .then(result => {
                if (result.data.Status) {
                    setPayroll(result.data.Result);
                    setFilteredPayroll(result.data.Result);
                } else {
                    alert(result.data.Error);
                }
            })
            .catch(err => {
                console.log(err);
                setError('Error fetching payroll data');
            });
    }, []);

    const calculateTotals = () => {
        return filteredPayroll.reduce((totals, record) => {
            totals.Micr += parseFloat(record['Micr']) || 0;
            totals.AccountNo += parseFloat(record['Account_no']) || 0;
            totals.AmountNo += parseFloat(record['Amount_no']) || 0;
            totals.DrawalName += parseFloat(record['Drawal_name']) || 0;
            return totals;
        }, { Micr: 0, AccountNo: 0, AmountNo: 0, DrawalName: 0 });
    };

    const totals = calculateTotals();

    useEffect(() => {
        axios.get('http://192.168.1.150:3000/auth/profile')
            .then(result => {
                if (result.data.Status) {
                    const filteredProfile = result.data.Result.find(c => c.username === username);
                    if (filteredProfile) {
                        setEmployeeNameToFilter(filteredProfile.name);
                    }
                } else {
                    alert(result.data.Error);
                }
            })
            .catch(err => console.log(err));
    }, [username]);

    useEffect(() => {
        // Filter by search term
        const lowercasedSearchTerm = searchTerm.toLowerCase();
        const filteredByDate = payroll.filter(item =>
            item['date'].toLowerCase().includes(lowercasedSearchTerm)
        );
        // Further filter by employee name
        const filteredByName = filterByEmployeeName(filteredByDate, employeeNameToFilter);
        setFilteredPayroll(filteredByName);
    }, [searchTerm, payroll, employeeNameToFilter]);

    // Filter by employee name (case-insensitive)
    const filterByEmployeeName = (data, name) => {
        return data.filter(item =>
            item['name'].trim().toLowerCase() === name.toLowerCase()
        );
    };

    // Define internal CSS styles for the table
    const tableStyles = {
        width: '100%',
        borderCollapse: 'collapse',
        marginTop: '20px',
        boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)', // Subtle shadow for depth
        borderRadius: '8px',
        overflow: 'hidden',
    };

    // Styles for table headers and cells
    const thStyles = {
        border: '1px solid #ddd',
        padding: '12px 15px',
        textAlign: 'left',
        backgroundColor: '#4CAF50', // Slightly dark green for the header
        color: '#fff',
        fontWeight: 'bold',
        textTransform: 'uppercase',
    };

    const tdStyles = {
        border: '1px solid #ddd',
        padding: '12px 15px',
    };

    // Row styles
    const rowStyles = {
        transition: 'background-color 0.3s ease, transform 0.3s ease',
    };

    const oddRowStyles = {
        backgroundColor: '#f9f9f9',
    };

    const evenRowStyles = {
        backgroundColor: '#ffffff',
    };

    const hoverRowStyles = {
        backgroundColor: '#e2f1e8', // Light green hover effect
        transform: 'scale(1.01)',
    };

    const navigate = useNavigate(); // Hook for navigation
    const [navOpen, setNavOpen] = useState(false); // State to handle sidebar visibility

    const toggleNav = () => {
        setNavOpen(!navOpen);
    };

    const handleNavClick = (path) => {
        navigate(path);
        setNavOpen(false); // Close the menu on navigation
    };

    return (
        <div>
            <header className="header11">
                <div><img src={img1} alt="Logo" /></div>
                <div className="header-left22">
                    <span className="header-title33">REGA </span>
                </div>
                <div className="header-center44">
                    <h1 className='h1'>Entry Details</h1>
                </div>
            </header>
            <div className='nav'>
                <nav className="sidebar">
                    <button
                        className="menu-icon" onClick={toggleNav}
                        style={{ borderRadius: '50%', padding: '4px', borderColor: 'white' }}
                    >⋮ ☰
                    </button>
                    {navOpen && (
                        <ul className="nav-list1">
                            <li className="nav-item">
                                <Link to='/demoprofile' className="nav-link">Profile</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/demopayroll" className="nav-link"
                                    style={{ background: '#a623ce', borderRadius: '20px' }}>Entry Record</Link>
                            </li>
                            <li className="nav-item">
                                <Link to='/demoattendance' className="nav-link">Attendance</Link>
                            </li>
                            <li className='nav-item'>
                                <Link to={'/'} className="nav-link">Logout</Link>
                            </li>
                        </ul>
                    )}
                    <div className='copy-nav'>
                        <ul className="nav-list">
                            <li className="nav-item">
                                <Link to='/demoprofile' className="nav-link">Profile</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/demopayroll" className="nav-link"
                                    style={{ background: '#a623ce', borderRadius: '20px' }}>Entry Record</Link>
                            </li>
                            <li className="nav-item">
                                <Link to='/demoattendance' className="nav-link">Attendance</Link>
                            </li>
                            <li className='nav-item'>
                                <Link to={'/'} className="nav-link">Logout</Link>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
            <div>
                {!navOpen && (
                    <main>
                        <div className="search-bar">
                            <input
                                type="text"
                                placeholder="Search by Date"
                                value={searchTerm}
                                onChange={e => setSearchTerm(e.target.value)}
                                style={{ margin: '20px 0', padding: '10px', borderRadius: '5px', border: '1px solid #ddd' }}
                            />
                        </div>
                        {error && <p style={{ color: 'red', textAlign: 'center' }}>{error}</p>}
                        <div className="payroll-table">
                            <table style={tableStyles}>
                                <thead>
                                    <tr>
                                        <th style={thStyles}>Sr no</th>
                                        <th style={thStyles}>Date</th>
                                        <th style={thStyles}>Name</th>
                                        <th style={thStyles}>Micr</th>
                                        <th style={thStyles}>Account No</th>
                                        <th style={thStyles}>Amount</th>
                                        <th style={thStyles}>Dwaral Name</th>
                                        <th style={thStyles}>Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {
                                        filteredPayroll.map((c, index) => {
                                            const rowTotal = (parseFloat(c['Micr']) || 0) + (parseFloat(c['Account_no']) || 0) + (parseFloat(c['Amount_no']) || 0) + (parseFloat(c['Drawal_name']) || 0);
                                            return (
                                                <tr
                                                    key={index}
                                                    style={{
                                                        ...rowStyles,
                                                        ...(index % 2 === 0 ? evenRowStyles : oddRowStyles),
                                                    }}
                                                    onMouseEnter={e => e.currentTarget.style.backgroundColor = hoverRowStyles.backgroundColor}
                                                    onMouseLeave={e => e.currentTarget.style.backgroundColor = index % 2 === 0 ? evenRowStyles.backgroundColor : oddRowStyles.backgroundColor}
                                                >
                                                    <td style={tdStyles}>{c['Sr_no']}</td>
                                                    <td style={tdStyles}>{c['date']}</td>
                                                    <td style={tdStyles}>{c['name']}</td>
                                                    <td style={tdStyles}>{c['Micr']}</td>
                                                    <td style={tdStyles}>{c['Account_no']}</td>
                                                    <td style={tdStyles}>{c['Amount_no']}</td>
                                                    <td style={tdStyles}>{c['Drawal_name']}</td>
                                                    <td style={tdStyles}>{rowTotal.toFixed(2)}</td>
                                                </tr>
                                            );
                                        })
                                    }
                                </tbody>
                            </table>
                        </div>
                    </main>
                )}
            </div>
        </div>
    );
};

export default payroll;
