import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import img1 from './image/logo.png';
import { FaFileExcel, FaFileWord, FaFilePdf, FaFileAlt } from 'react-icons/fa';

const bikasmajumdarapplication = () => {
  const [emails, setEmails] = useState([]);
  const [selectedEmail, setSelectedEmail] = useState(null);
  const [searchTerm, setSearchTerm] = useState(''); // Add this line
  const [openedEmails, setOpenedEmails] = useState(new Set());

  useEffect(() => {
    fetchEmails();
    const storedOpenedEmails = JSON.parse(localStorage.getItem('bikasmajumdaropenedEmails')) || [];
    setOpenedEmails(new Set(storedOpenedEmails));
  }, []);

  const fetchEmails = async () => {
    try {
      const response = await axios.get('http://192.168.1.150:3000/api/emails');
      setEmails(response.data);
    } catch (error) {
      console.error('Error fetching emails:', error);
    }
  };

  const handleEmailClick = (email) => {
    setSelectedEmail(email);
    const updatedOpenedEmails = new Set(openedEmails);
    updatedOpenedEmails.add(email.id);
    setOpenedEmails(updatedOpenedEmails);
    localStorage.setItem('bikasmajumdaropenedEmails', JSON.stringify(Array.from(updatedOpenedEmails)));
  };

  const handleBackToList = () => {
    setSelectedEmail(null);
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const offset = date.getTimezoneOffset() * 60000;
    const adjustedDate = new Date(date.getTime() - offset);
    return adjustedDate.toISOString().split('T')[0];
  };

  const isImageFile = (fileName) => {
    const imageExtensions = ['.jpg', '.jpeg', '.png', '.gif'];
    const fileExtension = fileName.slice(fileName.lastIndexOf('.')).toLowerCase();
    return imageExtensions.includes(fileExtension);
  };

  const getFileIcon = (fileName) => {
    const extension = fileName.split('.').pop().toLowerCase();
    switch (extension) {
      case 'xls':
      case 'xlsx':
        return <FaFileExcel className="attachment-icon" />;
      case 'doc':
      case 'docx':
        return <FaFileWord className="attachment-icon" />;
      case 'pdf':
        return <FaFilePdf className="attachment-icon" />;
      default:
        return <FaFileAlt className="attachment-icon" />;
    }
  };

  const getInitials = (name) => {
    const initials = name.split(' ').map((word) => word[0]).join('');
    return initials.toUpperCase();
  };

  // Filter emails based on the search term
  const filteredEmails = emails.filter(email =>
    email.email_to === 'bikas.majumdar@regaenterprises.com' || email.email_to === 'Bikas.majumdar@regaenterprises.com' ||
    email.email_to === 'Bikas.Majumdar@regaenterprises.com' &&
    (email.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
      email.email_from.toLowerCase().includes(searchTerm.toLowerCase()) ||
      email.name.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const navigate = useNavigate(); // Hook for navigation
  const [navOpen, setNavOpen] = useState(false); // State to handle sidebar visibility

  const toggleNav = () => {
    setNavOpen(!navOpen);
  };

  const handleNavClick = (path) => {
    navigate(path);
    setNavOpen(false); // Close the menu on navigation
  };

  return (
    <div>
      <header className="header11">
        <div><img src={img1} alt="Logo" /></div>
        <div className="header-left22">
          <span className="header-title33">REGA </span>
        </div>
        <div className="header-center44">
          <h1 className='h1'>Inbox</h1>
        </div>
      </header>
      <div className='nav'>
        <nav className="sidebar">
          <button
            className="menu-icon" onClick={toggleNav}
            style={{ borderRadius: '50%', padding: '4px', borderColor: 'white' }}
          >⋮ ☰
          </button>
          {navOpen && (
            <ul className="nav-list1">
              <li className="nav-item">
                <Link to='/bikasmajumdarprofile' className="nav-link">Profile</Link>
              </li>
              <li className="nav-item">
                <Link to="/bikasmajumdarpayroll" className="nav-link">Payroll</Link>
              </li>
              <li className="nav-item">
                <Link to='/bikasmajumdarattendance' className="nav-link">Attendance</Link>
              </li>
              <li className="nav-item">
                <Link to='/bikasmajumdarapplication' className="nav-link"
                  style={{ background: '#a623ce', borderRadius: '20px' }}>Application Letter</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/'} className="nav-link">Logout</Link>
              </li>
            </ul>
          )}
          <div className='copy-nav'>
            <ul className="nav-list">
              <li className="nav-item">
                <Link to='/bikasmajumdarprofile' className="nav-link">Profile</Link>
              </li>
              <li className="nav-item">
                <Link to="/bikasmajumdarpayroll" className="nav-link">Payroll</Link>
              </li>
              <li className="nav-item">
                <Link to='/bikasmajumdarattendance' className="nav-link">Attendance</Link>
              </li>
              <li className="nav-item">
                <Link to='/bikasmajumdarapplication' className="nav-link"
                  style={{ background: '#a623ce', borderRadius: '20px' }}>Application Letter</Link>
              </li>
              <li className='nav-item'>
                <Link to={'/'} className="nav-link">Logout</Link>
              </li>
            </ul>
          </div>
        </nav>
      </div>
      <div>
        {!navOpen && (
          <main className="main-content">
            <div className="gmail-like-container">
              <div className="gmail-menu">
                <ul className="gmail-menu-list">
                  <li className="gmail-menu-item activ"><Link to={'/bikasmajumdarapplication'}>Inbox</Link></li>
                  <li className="gmail-menu-item"><Link style={{ color: 'black' }} to={'/bikasmajumdarsend'}>Sent</Link></li>
                  <li className="gmail-menu-item"><Link style={{ color: 'black' }} to={'/bikasmajumdarcompose'}>Compose</Link></li>
                </ul>
              </div>
              <div className="gmail-content">
                <div className="search-bar">
                  <input
                    type="text"
                    placeholder="Search in email"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="search-input"
                  />
                </div>
                {filteredEmails.length === 0 ? (
                  <div className="no-mail">No mail Available</div>
                ) : (
                  <div className='gmail-content-log'>
                    {selectedEmail ? (
                      <div className='gmail-content-message'>
                        <button className="back-button" onClick={handleBackToList}>Back to List</button>
                        <h2>Email Details</h2>
                        <p className="email-date">Date: {formatDate(selectedEmail.date)}</p>
                        <p><strong>From:</strong> {selectedEmail.email_from}</p>
                        <p><strong>To:</strong> {selectedEmail.email_to}</p>
                        <p><strong>Subject:</strong> {selectedEmail.subject}</p>
                        <p><strong>Message:</strong></p>
                        <p>{selectedEmail.message}</p>
                        {selectedEmail.file_name && (
                          <div className='gmail-content-file'>
                            <p><strong>Attachment:</strong></p>
                            <a href={`http://192.168.1.150:3000/auth/files/${selectedEmail.file_name}`} target="_blank" rel="noopener noreferrer" className="attachment-link">
                              <div className="attachment-container">
                                {isImageFile(selectedEmail.file_name) ? (
                                  <img
                                    src={`http://192.168.1.150:3000/auth/files/${selectedEmail.file_name}`}
                                    alt="attachment"
                                    className="attachment-thumbnail"
                                  />
                                ) : (
                                  getFileIcon(selectedEmail.file_name)
                                )}
                                <div className="attachment-name">{selectedEmail.file_name}</div>
                              </div>
                            </a>
                          </div>
                        )}
                        <p className="email-timing">Timing: {selectedEmail.time}</p>
                      </div>
                    ) : (
                      <div className='gmail-content-outlook'>
                        <h2>Welcome to your Email Dashboard</h2>
                        {filteredEmails.map(email => (
                          <div key={email.id} className="email-preview" onClick={() => handleEmailClick(email)}>
                            <div className="initials-circle">{getInitials(email.name)}</div>
                            <div className="email-info">
                              <strong>To:</strong> {email.email_to}<br />
                              <strong>date:</strong> {formatDate(email.date)}
                              <br />
                              <strong>Subject:</strong> {email.subject}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </main>
        )}
      </div>
      <style>{` 
        .search-bar {
          margin-bottom: 20px;
          text-align: center;
        }

        .search-input {
          width: 100%;
          max-width: 600px;
          padding: 10px;
          font-size: 16px;
          border: 2px solid #ccc;
          border-radius: 15px;
          box-sizing: border-box; /* Ensure padding and border are included in width */
        }

        .search-bar input {
          background-color: white; /* Ensure the background color is white */
        }
      `}
      </style>
    </div>
  );
}

export default bikasmajumdarapplication