import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { formatISO, startOfDay, isMonday } from 'date-fns';
import img1 from './image/logo.png';
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import axios from 'axios';

const TanishaRoyAttendance = () => {
    const [date, setDate] = useState(new Date());
    const [searchDate, setSearchDate] = useState('');
    const [highlightedDates, setHighlightedDates] = useState([]);
    const [isPunchedIn, setIsPunchedIn] = useState(false);
    const [isPunchedOut, setIsPunchedOut] = useState(false);
    const [punchInTime, setPunchInTime] = useState('');
    const [punchOutTime, setPunchOutTime] = useState('');

    const [isEmerBreakStart, setIsEmerBreakStart] = useState(false);
    const [isEmerBreakStop, setIsEmerBreakStop] = useState(false);
    const [emerBreakStartTime, setEmerBreakStart] = useState('');
    const [emerBreakStopTime, setEmerBreakStop] = useState('');
    const [isEmerBreakStarted, setIsEmerBreakStarted] = useState(false);
    const [isEmerBreakStopped, setIsEmerBreakStopped] = useState(false);

    const [isEmer, setIsEmer] = useState(false);
    const [emerTime, setEmerTime] = useState('');

    const [backendEmergencyTime, setBackendEmergencyTime] = useState(0);

    const [isTeaBreakStart, setIsTeaBreakStart] = useState(false);
    const [isTeaBreakStop, setIsTeaBreakStop] = useState(false);
    const [teaBreakStartTime, setTeaBreakStartTime] = useState(null);
    const [teaBreakStopTime, setTeaBreakStopTime] = useState(null);
    const [isLunchBreakStart, setIsLunchBreakStart] = useState(false);
    const [isLunchBreakStop, setIsLunchBreakStop] = useState(false);
    const [lunchBreakStartTime, setLunchBreakStartTime] = useState(null);
    const [lunchBreakStopTime, setLunchBreakStopTime] = useState(null);
    const [isTeaBreakStart2, setIsTeaBreakStart2] = useState(false);
    const [isTeaBreakStop2, setIsTeaBreakStop2] = useState(false);
    const [teaBreakStart2Time, setTeaBreakStart2Time] = useState(null);
    const [teaBreakStop2Time, setTeaBreakStop2Time] = useState(null);
    const [isBreaksVisible, setIsBreaksVisible] = useState(false);
    const [absentDates, setAbsentDates] = useState(new Set());
    const [times, setTimes] = useState({ punch_In: '', TB1: '', TB2: '', LB1: '', LB2: '', TB3: '', TB4: '', punch_out: '', emergency: '' });

    useEffect(() => {
        const fetchAttendanceData = async () => {
            try {
                const result = await axios.get('http://192.168.1.150:3000/auth/getAttendance', {
                    params: { name: 'Tanisha Roy' }
                });

                if (result.data.Status) {
                    const dates = result.data.Result.map(record => new Date(record.date));
                    setHighlightedDates(dates);
                } else {
                    alert(result.data.Error);
                }
            } catch (err) {
                console.error(err);
            }
        };

        const fetchPunchTimes = async () => {
            const selectedDate = startOfDay(date);
            const formattedDate = formatISO(selectedDate, { representation: 'date' });

            try {
                const result = await axios.post('http://192.168.1.150:3000/auth/getPunchTimes', {
                    date: formattedDate,
                    name: 'Tanisha Roy'
                });

                if (result.data.Status) {
                    const { punch_In, punch_out, TB1, TB2, LB1, LB2, TB3, TB4, emergency, start, end } = result.data.Result;
                    setTimes({ punch_In, punch_out, TB1, TB2, LB1, LB2, TB3, TB4, start, end, emergency });
                    setPunchInTime(punch_In || '');
                    setPunchOutTime(punch_out || '');
                    setIsPunchedIn(!!punch_In);
                    setIsPunchedOut(!!punch_out);

                    setEmerBreakStart(start || '');
                    setEmerBreakStop(end || '');
                    setIsEmerBreakStart(!!start);
                    setIsEmerBreakStop(!!start);

                    setEmerTime(emergency || '');
                    setIsEmer(!!emergency);

                    setTeaBreakStartTime(TB1 || '');
                    setTeaBreakStopTime(TB2 || '');
                    setIsTeaBreakStart(!!TB1);
                    setIsTeaBreakStop(!!TB2);

                    setLunchBreakStartTime(LB1 || '');
                    setLunchBreakStopTime(LB2 || '');
                    setIsLunchBreakStart(!!LB1);
                    setIsLunchBreakStop(!!LB2);

                    setTeaBreakStart2Time(TB3 || '');
                    setTeaBreakStop2Time(TB4 || '');
                    setIsTeaBreakStart2(!!TB3);
                    setIsTeaBreakStop2(!!TB4);
                    setIsBreaksVisible(true);

                    if (emergency) {
                        const [hours, minutes, seconds] = emergency.split(':').map(Number);
                        setBackendEmergencyTime(hours * 3600 + minutes * 60 + seconds);
                        setIsBreaksVisible(true);
                    } else {
                        setBackendEmergencyTime(0);
                    }

                } else {
                    setPunchInTime('');
                    setPunchOutTime('');
                    setIsPunchedIn(false);
                    setIsPunchedOut(false);

                    setTeaBreakStartTime('');
                    setTeaBreakStopTime('');
                    setIsTeaBreakStart(false);
                    setIsTeaBreakStop(false);

                    setEmerTime('');
                    setIsEmer(false);

                    setLunchBreakStartTime('');
                    setLunchBreakStopTime('');
                    setIsLunchBreakStart(false);
                    setIsLunchBreakStop(false);

                    setTeaBreakStart2Time('');
                    setTeaBreakStop2Time('');
                    setIsTeaBreakStart2(false);
                    setIsTeaBreakStop2(false);

                    setEmerBreakStart('');
                    setEmerBreakStop('');
                    setIsEmerBreakStart(false);
                    setIsEmerBreakStop(false);

                    setIsBreaksVisible(false)
                }
            } catch (err) {
                console.error(err);
            }
        };

        fetchAttendanceData();
        fetchPunchTimes();

        const intervalId = setInterval(() => {
            fetchAttendanceData();
            fetchPunchTimes();
        }, 2000);

        return () => clearInterval(intervalId);
    }, [date]);

    const handleSearchDateChange = event => {
        setSearchDate(event.target.value);
    };

    const handlePunchIn = () => {
        const currentTime = new Date();
        if (date.toDateString() === currentTime.toDateString() && !absentDates.has(currentTime.toDateString())) {
            const punchInData = {
                Name: 'Tanisha Roy',
                date: currentTime.toISOString().split('T')[0],
                Punch_In: formatTime(currentTime),
                stat: 'Active'
            };

            axios.post('http://192.168.1.150:3000/auth/punchin', punchInData)
                .then(() => {
                    setPunchInTime(formatTime(currentTime));
                    setIsPunchedIn(true);
                    setIsBreaksVisible(true);
                })
                .catch(error => {
                    console.error('Error punching in:', error);
                    alert('Failed to punch in.');
                });
        } else {
            alert('Can not tag, this break is already used');
        }
    };

    const handleTeaBreakStart = () => {
        const currentTime = new Date();
        if (date.toDateString() === currentTime.toDateString() && !absentDates.has(currentTime.toDateString())) {
            const teabreakstart = {
                Name: 'Tanisha Roy',
                date: currentTime.toISOString().split('T')[0],
                teabreakstart: formatTime(currentTime),
            };

            axios.post('http://192.168.1.150:3000/auth/TB1', teabreakstart)
                .then(() => {
                    setTeaBreakStartTime(formatTime(currentTime));
                    setIsTeaBreakStart(true);
                    setIsBreaksVisible(true);
                })
                .catch(error => {
                    console.error('Error punching in:', error);
                    alert('Failed to punch in.');
                });
        } else {
            alert('Can not tag, this break is already used');
        }
    };

    const handleTeaBreakStop = () => {
        const currentTime = new Date();
        if (date.toDateString() === currentTime.toDateString() && isTeaBreakStart && !absentDates.has(currentTime.toDateString())) {
            const teabreak = calculateDuration(teaBreakStartTime, formatTime(currentTime));

            const teabreakstop = {
                date: currentTime.toISOString().split('T')[0],
                teaBreakStop: formatTime(currentTime),
                statu: teabreak.duration,
                Name: 'Tanisha Roy'
            };

            axios.post('http://192.168.1.150:3000/auth/TB2', teabreakstop)
                .then(response => {
                    if (response.data.Status) {
                        setTeaBreakStopTime(formatTime(currentTime));
                        setIsTeaBreakStop(true);
                    } else {
                        alert(`Failed to punch out. Backend response: ${response.data.Error}`);
                    }
                })
                .catch(error => {
                    console.error('Error punching out:', error);
                    alert(`Failed to punch out. Error details: ${error.message}`);
                });
        } else {
            alert('Can not tag, this break is already used');
        }
    };

    const handleLunchBreakStart = () => {
        const currentTime = new Date();
        if (date.toDateString() === currentTime.toDateString() && !absentDates.has(currentTime.toDateString())) {
            const lunchbreakstart = {
                Name: 'Tanisha Roy',
                date: formatISO(startOfDay(currentTime), { representation: 'date' }),
                lunchbreakstart: formatTime(currentTime),
            };

            axios.post('http://192.168.1.150:3000/auth/LB1', lunchbreakstart)
                .then(() => {
                    setLunchBreakStartTime(formatTime(currentTime));
                    setIsLunchBreakStart(true);
                })
                .catch(error => {
                    console.error('Error punching in:', error);
                    alert('Failed to punch in.');
                });
        } else {
            alert('Can not tag, this break is already used');
        }
    };

    const handleLunchBreakStop = () => {
        const currentTime = new Date();
        if (date.toDateString() === currentTime.toDateString() && isLunchBreakStart && !absentDates.has(currentTime.toDateString())) {
            const lunchbreak = calculateDuration(lunchBreakStartTime, formatTime(currentTime));

            const lunchbreakstop = {
                date: formatISO(startOfDay(currentTime), { representation: 'date' }),
                lunchbreakstop: formatTime(currentTime),
                statu: lunchbreak.duration,
                Name: 'Tanisha Roy'
            };

            axios.post('http://192.168.1.150:3000/auth/LB2', lunchbreakstop)
                .then(() => {
                    setLunchBreakStopTime(formatTime(currentTime));
                    setIsLunchBreakStop(true);
                })
                .catch(error => {
                    console.error('Error punching out:', error);
                    alert('Failed to punch out.');
                });
        } else {
            alert('Can not tag, this break is already used');
        }
    };

    const handleTeaBreakStart2 = () => {
        const currentTime = new Date();
        if (date.toDateString() === currentTime.toDateString() && !absentDates.has(currentTime.toDateString())) {
            const teabreakStart2 = {
                Name: 'Tanisha Roy',
                date: currentTime.toISOString().split('T')[0],
                teabreakstart2: formatTime(currentTime),
            };

            axios.post('http://192.168.1.150:3000/auth/TB3', teabreakStart2)
                .then(() => {
                    setTeaBreakStart2Time(formatTime(currentTime));
                    setIsTeaBreakStart2(true);
                    setIsBreaksVisible(true);
                })
                .catch(error => {
                    console.error('Error starting tea break 2:', error);
                    alert('Failed to start tea break 2.');
                });
        } else {
            alert('Can not tag, this break is already used');
        }
    };

    const handleTeaBreakStop2 = () => {
        const currentTime = new Date();
        if (date.toDateString() === currentTime.toDateString() && isTeaBreakStart2 && !absentDates.has(currentTime.toDateString())) {
            const teabreak2 = calculateDuration(teaBreakStart2Time, formatTime(currentTime));

            const teabreakStop2 = {
                Name: 'Tanisha Roy',
                date: currentTime.toISOString().split('T')[0],
                teaBreakstop2: formatTime(currentTime),
                statu: teabreak2.duration
            };

            axios.post('http://192.168.1.150:3000/auth/TB4', teabreakStop2)
                .then(response => {
                    if (response.data.Status) {
                        setTeaBreakStop2Time(formatTime(currentTime));
                        setIsTeaBreakStop2(true);
                    } else {
                        alert(`Failed to stop tea break 2. Backend response: ${response.data.Error}`);
                    }
                })
                .catch(error => {
                    console.error('Error stopping tea break 2:', error);
                    alert(`Failed to stop tea break 2. Error details: ${error.message}`);
                });
        } else {
            alert('Can not tag, this break is already used');
        }
    };

    const handlePunchOut = () => {
        const currentTime = new Date();
        if (date.toDateString() === currentTime.toDateString() && isPunchedIn && !absentDates.has(currentTime.toDateString())) {
            const { duration, totalMinutes } = calculateDuration(punchInTime, formatTime(currentTime));

            let status;
            if (totalMinutes < 300) status = 'Absent';
            else if (totalMinutes < 420) status = 'Half Day';
            else status = 'Full Day';

            const punchOutData = {
                date: formatISO(startOfDay(currentTime), { representation: 'date' }),
                Punch_Out: formatTime(currentTime),
                statu: duration,
                Name: 'Tanisha Roy',
                attendanceStatus: status
            };

            axios.post('http://192.168.1.150:3000/auth/punchout', punchOutData)
                .then(() => {
                    setPunchOutTime(formatTime(currentTime));
                    setIsPunchedOut(true);
                    setIsBreaksVisible(false);
                })
                .catch(error => {
                    console.error('Error punching out:', error);
                    alert('Failed to punch out.');
                });
        } else {
            alert('Can not tag, this break is already used');
        }
    };

    const calculateDuration = (startTime, endTime) => {
        const [startHours, startMinutes, startSeconds] = startTime.split(':').map(Number);
        const [endHours, endMinutes, endSeconds] = endTime.split(':').map(Number);

        const startDate = new Date(0, 0, 0, startHours, startMinutes, startSeconds);
        const endDate = new Date(0, 0, 0, endHours, endMinutes, endSeconds);

        const diff = endDate - startDate;
        const totalSeconds = Math.floor(diff / 1000);
        const hours = Math.floor(totalSeconds / 3600);
        const minutes = Math.floor((totalSeconds % 3600) / 60);
        const seconds = totalSeconds % 60;

        return {
            duration: `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`,
            totalMinutes: Math.floor(totalSeconds / 60),
            totalSeconds
        };
    };

    const formatTime = time => {
        const hours = String(time.getHours()).padStart(2, '0');
        const minutes = String(time.getMinutes()).padStart(2, '0');
        const seconds = String(time.getSeconds()).padStart(2, '0');
        return `${hours}:${minutes}:${seconds}`;
    };

    const handleSearchDateSubmit = event => {
        event.preventDefault();
        const parsedDate = new Date(searchDate);
        if (!isNaN(parsedDate.getTime())) {
            setDate(parsedDate);
            setSearchDate('');
        }
    };

    useEffect(() => {
        const storedEmerBreakStartTime = localStorage.getItem('TanishaRoyStartTime');
        const storedIsEmerBreakStarted = localStorage.getItem('isTanishaRoyStarted') === 'true';
        const storedIsEmerBreakStopped = localStorage.getItem('isTanishaRoyStopped') === 'true';
        const storedEmerBreakStopTime = localStorage.getItem('TanishaRoyStopTime');

        if (storedEmerBreakStartTime) {
            setEmerBreakStart(storedEmerBreakStartTime);
            setIsEmerBreakStarted(storedIsEmerBreakStarted);
        }

        if (storedEmerBreakStopTime) {
            setEmerBreakStop(storedEmerBreakStopTime);
            setIsEmerBreakStopped(storedIsEmerBreakStopped);
        }
    }, []);


    const handleEmerBreakStart = () => {
        const currentTime = new Date();
        if (date.toDateString() === currentTime.toDateString() && !absentDates.has(currentTime.toDateString())) {
            const emerbreakstart = {
                Name: 'Tanisha Roy',
                date: currentTime.toISOString().split('T')[0],
                emerbreakstart: formatTime(currentTime),
            };

            axios.post('http://192.168.1.150:3000/auth/emergencystart', emerbreakstart)
                .then(() => {
                    setEmerBreakStart(formatTime(currentTime));
                    setIsEmerBreakStarted(true);
                    setIsEmerBreakStopped(false);

                    // Save to local storage
                    localStorage.setItem('TanishaRoyStartTime', formatTime(currentTime));
                    localStorage.setItem('isTanishaRoyStarted', 'true');
                    localStorage.setItem('isTanishaRoyStopped', 'false');
                })
                .catch(error => {
                    console.error('Error punching :', error);
                    alert('Failed to punch .');
                });
        } else {
            alert('Can not tag, this break is already used');
        }
    };


    const handleEmerBreakStop = () => {
        const currentTime = new Date();

        if (date.toDateString() === currentTime.toDateString() && emerBreakStartTime && !absentDates.has(currentTime.toDateString())) {
            const emerBreakDuration = calculateDuration(emerBreakStartTime, formatTime(currentTime));

            const totalEmergencySeconds = emerBreakDuration.totalSeconds + backendEmergencyTime;
            const hours = Math.floor(totalEmergencySeconds / 3600);
            const minutes = Math.floor((totalEmergencySeconds % 3600) / 60);
            const seconds = totalEmergencySeconds % 60;

            const totalEmergencyDuration = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

            const emerbreakStop = {
                Name: 'Tanisha Roy',
                date: currentTime.toISOString().split('T')[0],
                emerBreakstop: formatTime(currentTime),
                statu: totalEmergencyDuration
            };

            axios.post('http://192.168.1.150:3000/auth/emergencystop', emerbreakStop)
                .then(response => {
                    if (response.data.Status) {
                        setEmerBreakStop(formatTime(currentTime));
                        setIsEmerBreakStopped(true);
                        setIsEmerBreakStarted(false);

                        // Save to local storage
                        localStorage.setItem('TanishaRoyStopTime', formatTime(currentTime));
                        localStorage.setItem('isTanishaRoyStopped', 'true');
                        localStorage.setItem('isTanishaRoyStarted', 'false');
                    } else {
                    }
                })
                .catch(error => {
                    console.error('Error stopping emergency break:', error);
                    alert(`Failed to stop emergency break. Error details: ${error.message}`);
                });
        } else {
            alert('Cannot stop emergency break. Either it was not started or the date is incorrect.');
        }
    };



    const handleClear = () => {
        const selectedDate = startOfDay(date);
        const formattedDate = formatISO(selectedDate, { representation: 'date' });

        console.log('Fetching punch times for date:', formattedDate); // Debug log

        try {
            const result = axios.post('http://192.168.1.150:3000/auth/deleteattendance', {
                date: formattedDate,
                Name: 'Tanisha Roy'
            });

            if (result.data.Status) {
                setPunchInTime('');
                setPunchOutTime('');
                setIsPunchedIn(false);
                setIsPunchedOut(false);
            } else {
                setIsPunchedIn(!!punch_In);
                setIsPunchedOut(!!punch_out);
            }
        } catch (err) {
            console.log(err);
        }
    };

    const tileClassName = ({ date }) => {
        const isHighlighted = highlightedDates.some(d => isSameDay(d, date));
        const today = new Date();
        const isPastDate = date < startOfDay(today);

        if (isMonday(date)) {
            return 'highlighted-monday'; // Highlight Mondays
        }

        if (isPastDate && !isHighlighted) {
            return 'absent-date'; // Highlight past dates not in data
        }

        return isHighlighted ? 'highlighted-date' : null;
    };

    const tileContent = ({ date }) => {
        const today = new Date();
        const isPastDate = date < startOfDay(today);
        const isHoliday = isMonday(date);

        if (isHoliday) {
            return <div className="holiday-label">WeekOff</div>;
        }

        if (isPastDate && !highlightedDates.some(d => isSameDay(d, date))) {
            return <div className="absent-label">Absent</div>;
        }

        return null;
    };

    const isSameDay = (date1, date2) => (
        date1.getFullYear() === date2.getFullYear() &&
        date1.getMonth() === date2.getMonth() &&
        date1.getDate() === date2.getDate()
    );

    const navigate = useNavigate(); // Hook for navigation
    const [navOpen, setNavOpen] = useState(false); // State to handle sidebar visibility

    const toggleNav = () => {
        setNavOpen(!navOpen);
    };

    const handleNavClick = (path) => {
        navigate(path);
        setNavOpen(false); // Close the menu on navigation
    };

    return (
        <div>
            <header className="header11">
                <img src={img1} alt="Logo" />
                <div className="header-left22">
                    <span className="header-title33">REGA</span>
                </div>
                <div className="header-center44">
                    <h1 className="h1">Attendance</h1>
                </div>
            </header>
            <div className='nav'>
                <nav className="sidebar">
                    <button
                        className="menu-icon" onClick={toggleNav}
                        style={{ borderRadius: '50%', padding: '4px', borderColor: 'white' }}
                    >⋮ ☰
                    </button>
                    {navOpen && (
                        <ul className="nav-list1">
                            <li className="nav-item">
                                <Link to='/tanisharoyprofile' className="nav-link">Profile</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/tanisharoypayroll" className="nav-link">Payroll</Link>
                            </li>
                            <li className="nav-item">
                                <Link to='/tanisharoyattendance' className="nav-link" style={{ background: '#a623ce', borderRadius: '20px' }}>Attendance</Link>
                            </li>
                            <li className="nav-item">
                                <Link to='/tanisharoyapplication' className="nav-link">Application Letter</Link>
                            </li>
                            <li className='nav-item'>
                                <Link to={'/'} className="nav-link">Logout</Link>
                            </li>
                        </ul>
                    )}
                    <div className='copy-nav'>
                        <ul className="nav-list">
                            <li className="nav-item">
                                <Link to='/tanisharoyprofile' className="nav-link">Profile</Link>
                            </li>
                            <li className="nav-item">
                                <Link to="/tanisharoypayroll" className="nav-link">Payroll</Link>
                            </li>
                            <li className="nav-item">
                                <Link to='/tanisharoyattendance' className="nav-link" style={{ background: '#a623ce', borderRadius: '20px' }}>Attendance</Link>
                            </li>
                            <li className="nav-item">
                                <Link to='/tanisharoyapplication' className="nav-link">Application Letter</Link>
                            </li>
                            <li className='nav-item'>
                                <Link to={'/'} className="nav-link">Logout</Link>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
            <div>
                {!navOpen && (
                    <main>
                        <div className="search-bar">
                            <form onSubmit={handleSearchDateSubmit}>
                                <input type="date" value={searchDate} onChange={handleSearchDateChange} />
                                <button type="submit">Search</button>
                            </form>
                        </div>
                        <div className="calendar-container">
                            <Calendar
                                onChange={setDate}
                                value={date}
                                tileClassName={tileClassName}
                                tileContent={tileContent}
                            />
                        </div>
                        <div className='attendance'>
                            <div className="buttons-container">
                                <button
                                    className="punch-button"
                                    style={{ marginTop: '45px', marginBottom: '45px', borderRadius: '8px' }}
                                    onClick={handlePunchIn}
                                    disabled={isPunchedIn || isPunchedOut}
                                >
                                    Punch In
                                </button>
                                {isBreaksVisible &&
                                    <div className='emergency' style={{ backgroundColor: '#93aef8' }}>
                                        <strong>Emergency Break : </strong>
                                        <button
                                            className="punch-button"
                                            onClick={handleEmerBreakStart}
                                            disabled={isEmerBreakStarted}
                                        >
                                            Start
                                        </button>
                                        <button
                                            className="punch-button"
                                            onClick={handleEmerBreakStop}
                                            disabled={!isEmerBreakStarted || isEmerBreakStopped}
                                        >
                                            Stop
                                        </button>
                                    </div>
                                }
                                <button
                                    className="punch-button"
                                    style={{ marginTop: '45px', marginBottom: '45px', borderRadius: '8px' }}
                                    onClick={handlePunchOut}
                                    disabled={!isPunchedIn || isPunchedOut}
                                >
                                    Punch Out
                                </button>
                            </div>
                            {isBreaksVisible && (
                                <div className='breaks' style={{ display: 'flex' }}>
                                    <div className='tea-break' style={{ padding: '30px 60px 30px 20px', fontSize: '25px', border: '5px' }}>
                                        <strong>Tea break : </strong>
                                        <div>
                                            <button
                                                className="punch-button"
                                                onClick={handleTeaBreakStart}
                                                disabled={isTeaBreakStart || isTeaBreakStop}
                                            >
                                                Start
                                            </button>
                                            <button
                                                className="punch-button"
                                                onClick={handleTeaBreakStop}
                                                disabled={!isTeaBreakStart || isTeaBreakStop}
                                            >
                                                Stop
                                            </button>
                                        </div>
                                    </div>
                                    <div className='lunch-break' style={{ padding: '30px 60px 30px 20px', fontSize: '25px', border: '5px' }}>
                                        <strong>Lunch break :</strong>
                                        <div style={{ gap: '10px' }}>
                                            <button
                                                className="punch-button"
                                                onClick={handleLunchBreakStart}
                                                disabled={isLunchBreakStart || isLunchBreakStop}
                                            >
                                                Start
                                            </button>
                                            <button
                                                className="punch-button"
                                                onClick={handleLunchBreakStop}
                                                disabled={!isLunchBreakStart || isLunchBreakStop}
                                            >
                                                Stop
                                            </button>
                                        </div>
                                    </div>
                                    <div className='tea-break-2' style={{ padding: '30px 60px 30px 20px', fontSize: '25px', border: '5px' }}>
                                        <strong>Tea break :</strong>
                                        <div>
                                            <button
                                                className="punch-button"
                                                onClick={handleTeaBreakStart2}
                                                disabled={isTeaBreakStart2 || isTeaBreakStop2}
                                            >
                                                Start
                                            </button>
                                            <button
                                                className="punch-button"
                                                onClick={handleTeaBreakStop2}
                                                disabled={!isTeaBreakStart2 || isTeaBreakStop2}
                                            >
                                                Stop
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>
                        <div className='copy-attendance'>
                            <div className="buttons-container">
                                <button
                                    className="punch-button"
                                    onClick={handlePunchIn}
                                    disabled={isPunchedIn || isPunchedOut}
                                >
                                    Punch In
                                </button>
                                <button
                                    className="punch-button"
                                    onClick={handlePunchOut}
                                    disabled={!isPunchedIn || isPunchedOut}
                                >
                                    Punch Out
                                </button>
                            </div>
                            {isBreaksVisible &&
                                <div className='emergency' style={{ backgroundColor: '#93aef8' }}>
                                    <strong>Emergency Break : </strong>
                                    <button
                                        className="punch-button"
                                        onClick={handleEmerBreakStart}
                                        disabled={isEmerBreakStarted}
                                    >
                                        Start
                                    </button>
                                    <button
                                        className="punch-button"
                                        onClick={handleEmerBreakStop}
                                        disabled={!isEmerBreakStarted || isEmerBreakStopped}
                                    >
                                        Stop
                                    </button>
                                </div>
                            }
                            {isBreaksVisible && (
                                <div className='breaks' style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}> {/* Added flex direction column and gap between sections */}
                                    <div className='tea-break' style={{ display: 'flex', gap: '10px', alignItems: 'center' }}> {/* Added gap between buttons */}
                                        <strong>Tea break :</strong>
                                        <div>
                                            <button
                                                className="punch-button"
                                                onClick={handleTeaBreakStart}
                                                disabled={isTeaBreakStart || isTeaBreakStop}
                                            >
                                                Start
                                            </button>
                                            <button
                                                className="punch-button"
                                                onClick={handleTeaBreakStop}
                                                disabled={!isTeaBreakStart || isTeaBreakStop}
                                            >
                                                Stop
                                            </button>
                                        </div>
                                    </div>
                                    <div className='lunch-break' style={{ display: 'flex', gap: '10px', alignItems: 'center' }}> {/* Added gap between buttons */}
                                        <strong style={{ marginRight: '10px' }}>Lunch break :</strong>
                                        <div style={{ display: 'flex' }}>
                                            <button
                                                className="punch-button"
                                                onClick={handleLunchBreakStart}
                                                disabled={isLunchBreakStart || isLunchBreakStop}
                                            >
                                                Start
                                            </button>
                                            <button
                                                className="punch-button"
                                                onClick={handleLunchBreakStop}
                                                disabled={!isLunchBreakStart || isLunchBreakStop}
                                            >
                                                Stop
                                            </button>
                                        </div>
                                    </div>
                                    <div className='tea-break-2' style={{ display: 'flex', gap: '10px', alignItems: 'center' }}> {/* Added gap between buttons */}
                                        <strong>Tea break :</strong>
                                        <div>
                                            <button
                                                className="punch-button"
                                                onClick={handleTeaBreakStart2}
                                                disabled={isTeaBreakStart2 || isTeaBreakStop2}
                                            >
                                                Start
                                            </button>
                                            <button
                                                className="punch-button"
                                                onClick={handleTeaBreakStop2}
                                                disabled={!isTeaBreakStart2 || isTeaBreakStop2}
                                            >
                                                Stop
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>
                        <div className="time-display" style={{ marginTop: '15px' }}>
                            {punchInTime && <div><span className='span1'>Punch In: </span>{punchInTime}</div>}
                            {teaBreakStartTime && <div><span>Tea Break Start At : </span>{teaBreakStartTime}</div>}
                            {teaBreakStopTime && <div><span>Tea Break Over At : </span>{teaBreakStopTime}</div>}
                            {lunchBreakStartTime && <div><span>Lunch Break Start At : </span>{lunchBreakStartTime}</div>}
                            {lunchBreakStopTime && <div><span>Lunch Break Over At : </span>{lunchBreakStopTime}</div>}
                            {teaBreakStart2Time && <div><span>Tea Break 2 Start At : </span>{teaBreakStart2Time}</div>}
                            {teaBreakStop2Time && <div><span>Tea Break 2 Over At : </span>{teaBreakStop2Time}</div>}
                            {punchOutTime && <div><span className='span1'>Punch Out : </span>{punchOutTime}</div>}
                            {emerTime && <div><span>Emergency duration : </span>{emerTime} </div>}
                        </div>
                    </main>
                )}
            </div>
        </div>
    );
};

export default TanishaRoyAttendance;
