import React, { useState } from 'react';
import './login.css';
import img1 from './image/logo.png';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../AuthContext';

const Login = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  axios.defaults.withCredentials = true;

  const [error, setError] = useState('');
  const [values, setValues] = useState({
    username: '',
    password: ''
  });

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    try {
      const result = await axios.post('http://192.168.1.150:3000/auth/userlogin', values);
      if (result.data.loginStatus) {
        const { username } = result.data;
  
        // Save username to local storage
        localStorage.setItem('username', username);
  
        login({ isAdmin: false });
  
        // Navigate based on username
        if (username === 'Aniket.Sharma@regaenterprises.com') {
          navigate('/profile');
        } else if (username === 'Tanisha.Roy@regaenterprises.com') {
          navigate('/tanisharoyprofile');
        } else if (username === 'Sumit.Potraj@regaenterprises.com') {
          navigate('/sumitpotrajprofile');
        } else if (username === 'Bikas.Majumdar@regaenterprises.com') {
          navigate('/bikasmajumdarprofile');
        } else if (username === 'Ashu.Khan@regaenterprises.com') {
          navigate('/ashukhanprofile');
        } else {
          navigate('/demoprofile');
        }
      } else {
        setError(result.data.Error);
      }
    } catch (err) {
      console.error('Error:', err);
      setError('An error occurred. Please try again.');
    }
  };
  

  return (
    <div>
      <header className='header' style={{ display: 'flex', justifyContent: 'center', 
        alignItems: 'center', textAlign: 'center' }}>
        <div className='image1'><img src={img1} alt="Logo" /></div>
        <div className='header1'>
          <div className="highlighted-text">REGA</div>
        </div>
      </header>
      <div id='content1' className='loginPage'>
        <div id='content2' className='loginForm'>
          <div className='danger-text'>
            <strong>{error && error}</strong>
          </div>
          <h2>User Login</h2>
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label htmlFor='t1'>Enter Username:</label>
              <input
                type='text'
                id='t1'
                name='username'
                placeholder='Username'
                className='form-control'
                value={values.username}
                onChange={(e) => setValues({ ...values, username: e.target.value })}
                required
              />
            </div>
            <div className="form-group">
              <label htmlFor='t2'>Enter Password:</label>
              <input
                type='password'
                id='t2'
                name='password'
                placeholder='Password'
                className='form-control'
                value={values.password}
                onChange={(e) => setValues({ ...values, password: e.target.value })}
                required
              />
            </div>
            <button type="submit" className='btn btn-success w-100'>Login</button>
            <Link to={'/admin'} id='a'>Admin Login</Link>
          </form>
        </div>
      </div>
    </div>
  );
}

export default Login;
