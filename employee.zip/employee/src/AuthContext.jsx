import { createContext, useContext, useState, useEffect } from 'react';
import axios from 'axios';

const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [isAdmin, setIsAdmin] = useState(false);

    useEffect(() => {
        // Check if the user is already authenticated
        axios.get('http://192.168.1.150:3000/auth/check', { withCredentials: true })
            .then(response => {
                if (response.data.isAuthenticated) {
                    setIsAuthenticated(true);
                    setIsAdmin(response.data.isAdmin);
                }
            });
    }, []);

    const login = (user) => {
        setIsAuthenticated(true);
        setIsAdmin(user.isAdmin);
    };

    const logout = () => {
        axios.get('http://192.168.1.150:3000/auth/logout', { withCredentials: true })
            .then(() => {
                setIsAuthenticated(false);
                setIsAdmin(false);
            });
    };

    return (
        <AuthContext.Provider value={{ isAuthenticated, isAdmin, login, logout }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => useContext(AuthContext);
