import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { AuthProvider } from './AuthContext';
import { UserProtectedRoute, AdminProtectedRoute } from './ProtectedRoute';
import Admin from './components/admin';
import Login from './components/Login';
import '@fortawesome/fontawesome-free/css/all.css';

/*Admin */
import AdminView from './components/adminpages/Admindashboard';
import AdminPayroll from './components/adminpages/adminpayroll';
import AdminAttendance from './components/adminpages/Attendancerecord';
import AdminApplication from './components/adminpages/Applicationrecord';
import AdminEmployees from './components/adminpages/employessss';
import Add from './components/adminpages/add';
import EditAttendance from './components/adminpages/editemployee';
import Adminsend from './components/adminpages/adminsend';
import Admincompose from './components/adminpages/admincompose';
import Adminaxispayroll from './components/adminpages/axis/bankpayroll';
import Adminaxisattendance from './components/adminpages/axis/bankattendance';
import Axisadd from './components/adminpages/axis/editpayroll';
import Addemployee from './components/adminpages/addEmployee';

/*Admin all attendance record */
import Aaniket from './components/adminpages/employeeattendance/Aaniket';
import Tanisharoy from './components/adminpages/employeeattendance/tanisharoy'
import Ashukhan from './components/adminpages/employeeattendance/ashu';
import Bikas from './components/adminpages/employeeattendance/bikas';
import Sumit from './components/adminpages/employeeattendance/sumit';
import Demo from './components/adminpages/employeeattendance/axis/demo';

/*admin all profile record */
import Tanishapro from './components/adminpages/employeeprofile/tanishapro';
import Aniketpro from './components/adminpages/employeeprofile/aniketpro';
import Sumitpro from './components/adminpages/employeeprofile/sumitpro';
import Ashukhanpro from './components/adminpages/employeeprofile/ashukhanpro';
import Bikaspro from './components/adminpages/employeeprofile/bikaspro';
import Demopro from './components/adminpages/employeeprofile/axis/demopro';

/*aniket */
import Application from './components/IT department/userpages/application';
import Attendance from './components/IT department/userpages/attendance';
import Payroll from './components/IT department/userpages/payroll';
import Profile from './components/IT department/userpages/profile';
import Compose from './components/IT department/userpages/Compose';
import Sent from './components/IT department/userpages/sent';

/* tanish*/
import Tanisharoypayroll from './components/IT department/TanishaRoy/tanisharoypayroll'
import Tanisharoyprofile from './components/IT department/TanishaRoy/tanisharoyprofile';
import Tanisharoyattendance from './components/IT department/TanishaRoy/tanisharoyattendance';
import Tanisharoyapplication from './components/IT department/TanishaRoy/tanisharoyapplication';
import Tanisharoysent from './components/IT department/TanishaRoy/tanisharoysent';
import Tanisharoycompose from './components/IT department/TanishaRoy/tanisharoycompose';

/*sumit potraj */
import Sumitpotrajprofile from './components/insurance/Sumit potraj/sumitpotrajprofile';
import Sumitpotrajpayroll from './components/insurance/Sumit potraj/sumitpotrajpayroll';
import Sumitpotrajattendance from './components/insurance/Sumit potraj/sumitpotrajattendance';
import Sumitpotrajapplication from './components/insurance/Sumit potraj/sumitpotrajapplication';
import Sumitpotrajsent from './components/insurance/Sumit potraj/sumitpotrajsent';
import Sumitpotrajcompose from './components/insurance/Sumit potraj/sumitpotrajcompose';

/*bikas majumdar */
import Bikasmajumdarprofile from './components/IT department/bikas majumdar/bikasmajumdarprofile';
import Bikasmajumdarpayroll from './components/IT department/bikas majumdar/bikasmajumdarpayroll';
import Bikasmajumdarattendance from './components/IT department/bikas majumdar/bikasmajumdarattendance';
import Bikasmajumdarapplication from './components/IT department/bikas majumdar/bikasmajumdarapplication';
import Bikasmajumdarsent from './components/IT department/bikas majumdar/bikasmajumdarsend';
import Bikasmajumdarcompose from './components/IT department/bikas majumdar/bikasmajumdarcompose';

/*Asrunnish khan */
import Ashukhanprofile from './components/Asrunnisha Khan/asrunnishakhanprofile';
import Ashukhanpayroll from './components/Asrunnisha Khan/asrunnishakhanpayroll';
import Ashukhanattendance from './components/Asrunnisha Khan/asrunnishakhanattendance';
import Ashukhanapplication from './components/Asrunnisha Khan/asrunnishakhanapplication';
import Ashukhansent from './components/Asrunnisha Khan/asrunnishakhansent';
import Ashukhancompose from './components/Asrunnisha Khan/asrunnishakhancompose';
import Ashukhanstatus from './components/Asrunnisha Khan/employeesstatus';

/*axis entry */
import Demoprofile from './components/axis/demo/profile';
import Demorecord from './components/axis/demo/payroll';
import Demoattendance from './components/axis/demo/attendance';



function App() {
    return (
        <AuthProvider>
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<Login />} />
                    <Route path="/admin" element={<Admin />} />
                    <Route path="/application" element={
                        <UserProtectedRoute>
                            <Application />
                        </UserProtectedRoute>
                    } />
                    <Route path="/attendance" element={
                        <UserProtectedRoute>
                            <Attendance />
                        </UserProtectedRoute>
                    } />
                    <Route path="/payroll" element={
                        <UserProtectedRoute>
                            <Payroll />
                        </UserProtectedRoute>
                    } />
                    <Route path="/profile" element={
                        <UserProtectedRoute>
                            <Profile />
                        </UserProtectedRoute>
                    } />
                    <Route path="/compose" element={
                        <UserProtectedRoute>
                            <Compose />
                        </UserProtectedRoute>
                    } />
                    <Route path="/send" element={
                        <UserProtectedRoute>
                            <Sent />
                        </UserProtectedRoute>
                    } />

                    //tanisha roy navigation

                    <Route path="/tanisharoyprofile" element={
                        <UserProtectedRoute>
                            <Tanisharoyprofile />
                        </UserProtectedRoute>
                    } />
                    <Route path="/tanisharoyattendance" element={
                        <UserProtectedRoute>
                            <Tanisharoyattendance />
                        </UserProtectedRoute>
                    } />
                    <Route path="/tanisharoysend" element={
                        <UserProtectedRoute>
                            <Tanisharoysent />
                        </UserProtectedRoute>
                    } />
                    <Route path="/tanisharoycompose" element={
                        <UserProtectedRoute>
                            <Tanisharoycompose />
                        </UserProtectedRoute>
                    } />
                    <Route path="/tanisharoypayroll" element={
                        <UserProtectedRoute>
                            <Tanisharoypayroll />
                        </UserProtectedRoute>
                    } />
                    <Route path="/tanisharoyapplication" element={
                        <UserProtectedRoute>
                            <Tanisharoyapplication />
                        </UserProtectedRoute>
                    } />

//asrunnisha khan navigation

                    <Route path="/ashukhanprofile" element={
                        <UserProtectedRoute>
                            <Ashukhanprofile />
                        </UserProtectedRoute>
                    } />
                    <Route path="/ashukhanattendance" element={
                        <UserProtectedRoute>
                            <Ashukhanattendance />
                        </UserProtectedRoute>
                    } />
                    <Route path="/ashukhansend" element={
                        <UserProtectedRoute>
                            <Ashukhansent />
                        </UserProtectedRoute>
                    } />
                    <Route path="/ashukhancompose" element={
                        <UserProtectedRoute>
                            <Ashukhancompose />
                        </UserProtectedRoute>
                    } />
                    <Route path="/ashukhanpayroll" element={
                        <UserProtectedRoute>
                            <Ashukhanpayroll />
                        </UserProtectedRoute>
                    } />
                    <Route path="/ashukhanapplication" element={
                        <UserProtectedRoute>
                            <Ashukhanapplication />
                        </UserProtectedRoute>
                    } />
                    <Route path="/ashukhanstatus" element={
                        <UserProtectedRoute>
                            <Ashukhanstatus />
                        </UserProtectedRoute>
                    } />

// bikas majumdar navigation

                    <Route path="/bikasmajumdarprofile" element={
                        <UserProtectedRoute>
                            <Bikasmajumdarprofile />
                        </UserProtectedRoute>
                    } />
                    <Route path="/bikasmajumdarattendance" element={
                        <UserProtectedRoute>
                            <Bikasmajumdarattendance />
                        </UserProtectedRoute>
                    } />
                    <Route path="/bikasmajumdarsend" element={
                        <UserProtectedRoute>
                            <Bikasmajumdarsent />
                        </UserProtectedRoute>
                    } />
                    <Route path="/bikasmajumdarcompose" element={
                        <UserProtectedRoute>
                            <Bikasmajumdarcompose />
                        </UserProtectedRoute>
                    } />
                    <Route path="/bikasmajumdarpayroll" element={
                        <UserProtectedRoute>
                            <Bikasmajumdarpayroll />
                        </UserProtectedRoute>
                    } />
                    <Route path="/bikasmajumdarapplication" element={
                        <UserProtectedRoute>
                            <Bikasmajumdarapplication />
                        </UserProtectedRoute>
                    } />

                    //sumit potraj navigation

                    <Route path="/sumitpotrajprofile" element={
                        <UserProtectedRoute>
                            <Sumitpotrajprofile />
                        </UserProtectedRoute>
                    } />
                    <Route path="/sumitpotrajattendance" element={
                        <UserProtectedRoute>
                            <Sumitpotrajattendance />
                        </UserProtectedRoute>
                    } />
                    <Route path="/sumitpotrajsend" element={
                        <UserProtectedRoute>
                            <Sumitpotrajsent />
                        </UserProtectedRoute>
                    } />
                    <Route path="/sumitpotrajcompose" element={
                        <UserProtectedRoute>
                            <Sumitpotrajcompose />
                        </UserProtectedRoute>
                    } />
                    <Route path="/sumitpotrajpayroll" element={
                        <UserProtectedRoute>
                            <Sumitpotrajpayroll />
                        </UserProtectedRoute>
                    } />
                    <Route path="/sumitpotrajapplication" element={
                        <UserProtectedRoute>
                            <Sumitpotrajapplication />
                        </UserProtectedRoute>
                    } />

                    //admin attendance record navigation

                    <Route path="/aniket" element={
                        <AdminProtectedRoute>
                            <Aaniket />
                        </AdminProtectedRoute>
                    } />
                    <Route path="/tanisharoy" element={
                        <AdminProtectedRoute>
                            <Tanisharoy />
                        </AdminProtectedRoute>
                    } />
                    <Route path="/sumit" element={
                        <AdminProtectedRoute>
                            <Sumit />
                        </AdminProtectedRoute>
                    } />
                    <Route path="/ashukhan" element={
                        <AdminProtectedRoute>
                            <Ashukhan />
                        </AdminProtectedRoute>
                    } />
                    <Route path="/bikas" element={
                        <AdminProtectedRoute>
                            <Bikas />
                        </AdminProtectedRoute>
                    } />
                    <Route path="/demo" element={
                        <AdminProtectedRoute>
                            <Demo />
                        </AdminProtectedRoute>
                    } />

 //admin profile record navigation

                    <Route path="/tanishapro" element={
                        <AdminProtectedRoute>
                            <Tanishapro />
                        </AdminProtectedRoute>
                    } />
                    <Route path="/aniketpro" element={
                        <AdminProtectedRoute>
                            <Aniketpro />
                        </AdminProtectedRoute>
                    } />
                    <Route path="/sumitpro" element={
                        <AdminProtectedRoute>
                            <Sumitpro />
                        </AdminProtectedRoute>
                    } />
                    <Route path="/bikaspro" element={
                        <AdminProtectedRoute>
                            <Bikaspro />
                        </AdminProtectedRoute>
                    } />
                    <Route path="/ashukhanpro" element={
                        <AdminProtectedRoute>
                            <Ashukhanpro />
                        </AdminProtectedRoute>
                    } />
                    <Route path="/demopro" element={
                        <AdminProtectedRoute>
                            <Demopro />
                        </AdminProtectedRoute>
                    } />


                    //admin

                    <Route path="/adminview" element={
                        <AdminProtectedRoute>
                            <AdminView />
                        </AdminProtectedRoute>
                    } />
                    <Route path="/adminpayroll" element={
                        <AdminProtectedRoute>
                            <AdminPayroll />
                        </AdminProtectedRoute>
                    } />
                    <Route path="/adminaxispayroll" element={
                        <AdminProtectedRoute>
                            <Adminaxispayroll />
                        </AdminProtectedRoute>
                    } />
                    <Route path="/adminattendance" element={
                        <AdminProtectedRoute>
                            <AdminAttendance />
                        </AdminProtectedRoute>
                    } />
                    <Route path="/adminaxisattendance" element={
                        <AdminProtectedRoute>
                            <Adminaxisattendance />
                        </AdminProtectedRoute>
                    } />
                    <Route path="/adminapplication" element={
                        <AdminProtectedRoute>
                            <AdminApplication />
                        </AdminProtectedRoute>
                    } />
                    <Route path="/adminemployee" element={
                        <AdminProtectedRoute>
                            <AdminEmployees />
                        </AdminProtectedRoute>
                    } />
                    <Route path="/add" element={
                        <AdminProtectedRoute>
                            <Add />
                        </AdminProtectedRoute>
                    } />
                    <Route path="/editattendance" element={
                        <AdminProtectedRoute>
                            <EditAttendance />
                        </AdminProtectedRoute>
                    } />
                    <Route path="/adminsend" element={
                        <AdminProtectedRoute>
                            <Adminsend />
                        </AdminProtectedRoute>
                    } />
                    <Route path="/admincompose" element={
                        <AdminProtectedRoute>
                            <Admincompose />
                        </AdminProtectedRoute>
                    } />
                    <Route path="/axisadd" element={
                        <AdminProtectedRoute>
                            <Axisadd />
                        </AdminProtectedRoute>
                    } />
                    <Route path="/Addemployee" element={
                            <Addemployee />
                    } />

// axis demo

                    <Route path='/demoprofile' element={
                        <UserProtectedRoute>
                            <Demoprofile />
                        </UserProtectedRoute>
                    }
                    />
                    <Route path='/demopayroll' element={
                        <UserProtectedRoute>
                            <Demorecord />
                        </UserProtectedRoute>
                    }
                    />
                    <Route path='/demoattendance' element={
                        <UserProtectedRoute>
                            <Demoattendance />
                        </UserProtectedRoute>
                    }
                    />

                </Routes>
            </BrowserRouter>
        </AuthProvider>
    );
}

export default App;
